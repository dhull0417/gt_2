import { toast } from '@/contexts/ToastContext';
import React, { useState, useEffect, useRef } from "react";
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    Alert,
    ActivityIndicator,
} from "react-native";
import { PressableOpacity } from '@/components/ui/PressableOpacity';
import { ToggleSwitch } from '@/components/ui/ToggleSwitch';
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@clerk/expo";
import { Feather } from '@expo/vector-icons';
import { SafeAreaView } from "react-native-safe-area-context";
import { useGetGroupDetails } from "../../hooks/useGetGroupDetails";
import { LoadingAnimation } from "@/components/LoadingAnimation";
import { useApiClient, groupApi } from "../../utils/api";
import { broadcastGroupUpdate, broadcastMeetupUpdate } from "../../utils/groupRealtime";
import { getErrorMessage } from "../../utils/networkError";
import NativeTimePicker, { timeStringToDate } from "@/components/NativeTimePicker";
import InfoBubble from "@/components/InfoBubble";
import { useAppearance, useThemeColors } from "@/contexts/AppearanceContext";
import type { ThemeColors } from "@/constants/theme";

// Same day-count for open/deadline still needs a time-of-day check — leadDays >= deadlineDays alone isn't enough
const timeToMinutes = (time: string): number => {
    const t = timeStringToDate(time);
    return t.getHours() * 60 + t.getMinutes();
};


// ─── Main Screen ──────────────────────────────────────────────────────────────

interface RsvpSettings {
    rsvpRestricted: boolean;
    leadEnabled: boolean;
    leadDays: number;
    leadTime: string;
    deadlineEnabled: boolean;
    deadlineDays: number;
    deadlineTime: string;
}

const EditJitScreen = () => {
    const colors = useThemeColors();
    const { scheme } = useAppearance();
    const isDark = scheme === 'dark';
    const { id, scheduleId } = useLocalSearchParams<{ id: string; scheduleId: string }>();
    const router = useRouter();
    const api = useApiClient();
    const queryClient = useQueryClient();
    const { getToken } = useAuth();

    const { data: group, isLoading: loadingGroup } = useGetGroupDetails(id);
    const schedule = group?.schedules?.find(s => s._id === scheduleId) ?? null;

    const [rsvpRestricted, setRsvpRestricted] = useState(true);
    const [leadEnabled, setLeadEnabled] = useState(true);
    const [leadDays, setLeadDays] = useState(5);
    const [leadTime, setLeadTime] = useState("09:00 AM");
    const [showLeadTimePicker, setShowLeadTimePicker] = useState(false);
    const [deadlineEnabled, setDeadlineEnabled] = useState(false);
    const [deadlineDays, setDeadlineDays] = useState(2);
    const [deadlineTime, setDeadlineTime] = useState("09:00 AM");
    const [showDeadlineTimePicker, setShowDeadlineTimePicker] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    // Initialized once when group data arrives
    const originalRef = useRef<RsvpSettings | null>(null);
    const initialized = useRef(false);

    useEffect(() => {
        if (schedule && !initialized.current) {
            initialized.current = true;
            const initial: RsvpSettings = {
                rsvpRestricted: schedule.generationLeadDays != null || schedule.generationDeadlineDays != null,
                leadEnabled: schedule.generationLeadDays != null,
                leadDays: schedule.generationLeadDays ?? 5,
                leadTime: schedule.generationLeadTime || "09:00 AM",
                deadlineEnabled: schedule.generationDeadlineDays != null,
                deadlineDays: schedule.generationDeadlineDays ?? 2,
                deadlineTime: schedule.generationDeadlineTime || "09:00 AM",
            };
            originalRef.current = initial;
            setRsvpRestricted(initial.rsvpRestricted);
            setLeadEnabled(initial.leadEnabled);
            setLeadDays(initial.leadDays);
            setLeadTime(initial.leadTime);
            setDeadlineEnabled(initial.deadlineEnabled);
            setDeadlineDays(initial.deadlineDays);
            setDeadlineTime(initial.deadlineTime);
        }
    }, [schedule]);

    const hasChanged = !!originalRef.current && (
        originalRef.current.rsvpRestricted !== rsvpRestricted ||
        originalRef.current.leadEnabled !== leadEnabled ||
        originalRef.current.leadDays !== leadDays ||
        originalRef.current.leadTime !== leadTime ||
        originalRef.current.deadlineEnabled !== deadlineEnabled ||
        originalRef.current.deadlineDays !== deadlineDays ||
        originalRef.current.deadlineTime !== deadlineTime
    );

    const openLeadTimePicker = () => {
        setShowDeadlineTimePicker(false);
        setShowLeadTimePicker(true);
    };

    const openDeadlineTimePicker = () => {
        setShowLeadTimePicker(false);
        setShowDeadlineTimePicker(true);
    };

    const handleSave = async () => {
        if (!id || !scheduleId) return;
        setIsSaving(true);
        try {
            await groupApi.updateSchedule(api, id, scheduleId, {
                generationLeadDays: rsvpRestricted && leadEnabled ? leadDays : null,
                generationLeadTime: leadTime,
                generationDeadlineDays: rsvpRestricted && deadlineEnabled ? deadlineDays : null,
                generationDeadlineTime: deadlineTime,
            });

            // Refresh queries to ensure changes are visible in settings and group details
            await Promise.all([
                queryClient.invalidateQueries({ queryKey: ['groupDetails', id] }),
                queryClient.invalidateQueries({ queryKey: ['groups'] }),
                queryClient.invalidateQueries({ queryKey: ['meetups'] }),
            ]);
            broadcastGroupUpdate(getToken, id);
            broadcastMeetupUpdate(getToken, id);

            toast.success("RSVP settings saved.");
            router.back();
        } catch (error: any) {
            Alert.alert("Error", getErrorMessage(error, "Failed to update RSVP settings."));
        } finally {
            setIsSaving(false);
        }
    };

    // ── Loading state ─────────────────────────────────────────────────────────

    if (loadingGroup || !group) {
        return (
            <SafeAreaView style={[s.safe, { backgroundColor: colors.background }]}>
                <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                    <LoadingAnimation />
                </View>
            </SafeAreaView>
        );
    }

    if (!schedule) {
        return (
            <SafeAreaView style={[s.safe, { backgroundColor: colors.background }]}>
                <View style={{ flex: 1, justifyContent: "center", alignItems: "center", padding: 24 }}>
                    <Text style={[s.screenSub, { color: colors.textFaint }]}>This schedule couldn't be found. It may have been removed.</Text>
                    <PressableOpacity style={[s.primaryBtn, { backgroundColor: colors.brand }]} onPress={() => router.back()}>
                        <Text style={s.primaryBtnText}>Go back</Text>
                    </PressableOpacity>
                </View>
            </SafeAreaView>
        );
    }

    const disabledBtnBg = isDark ? '#2A3A52' : '#93C5FD';

    // ── Render ────────────────────────────────────────────────────────────────

    return (
        <SafeAreaView style={[s.safe, { backgroundColor: colors.background }]}>
            <View style={s.screen}>
                <View style={[s.screenHeader, { borderBottomColor: colors.border, backgroundColor: colors.surface }]}>
                    <PressableOpacity accessibilityLabel="Go back" onPress={() => router.back()} style={s.iconBtn}>
                        <Feather name="arrow-left" size={24} color={colors.textSecondary} />
                    </PressableOpacity>
                    <Text style={[s.headerTitle, { color: colors.textPrimary }]}>RSVP Settings</Text>
                    <View style={{ width: 36 }} />
                </View>

                <ScrollView
                    style={{ flex: 1 }}
                    contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 40 }}
                    showsVerticalScrollIndicator={false}
                >
                    <Text style={[s.screenSub, { color: colors.textFaint }]}>Control when members can RSVP to "{schedule.name}" meetups.</Text>

                    <Text style={[s.fieldLabel, { color: colors.textFaint }]}>Limit when people can RSVP?</Text>
                    <View style={s.boolRow}>
                        <PressableOpacity style={[s.boolBtn, { borderColor: colors.border, backgroundColor: colors.surface }, !rsvpRestricted && { borderColor: colors.brand, backgroundColor: colors.brandSoft }]}
                            onPress={() => setRsvpRestricted(false)}>
                            <Text style={[s.boolBtnText, { color: colors.textMuted }, !rsvpRestricted && { color: colors.brand }]}>Allow anytime</Text>
                        </PressableOpacity>
                        <PressableOpacity style={[s.boolBtn, { borderColor: colors.border, backgroundColor: colors.surface }, rsvpRestricted && { borderColor: colors.brand, backgroundColor: colors.brandSoft }]}
                            onPress={() => setRsvpRestricted(true)}>
                            <Text style={[s.boolBtnText, { color: colors.textMuted }, rsvpRestricted && { color: colors.brand }]}>Limit RSVPs</Text>
                        </PressableOpacity>
                    </View>

                    {rsvpRestricted && (
                        <View style={{ marginTop: 14, gap: 14 }}>
                            <View>
                                <View style={s.toggleRow}>
                                    <View style={s.toggleRowLabelWrap}>
                                        <Text style={[s.toggleRowLabel, { color: colors.textSecondary }]}>Earliest time to RSVP</Text>
                                        <InfoBubble
                                            title="Earliest time to RSVP"
                                            description={"This sets the earliest time and day people can respond.\n\nIt's a number of days before the meetup, at a specific time.\n\nTurn it off to allow RSVPs as soon as the meetup is created."}
                                        />
                                    </View>
                                    <ToggleSwitch value={leadEnabled} onValueChange={(v) => {
                                        setLeadEnabled(v);
                                        const nextLeadDays = v && deadlineEnabled && leadDays < deadlineDays ? deadlineDays : leadDays;
                                        if (nextLeadDays !== leadDays) setLeadDays(nextLeadDays);
                                        if (v && deadlineEnabled && nextLeadDays === deadlineDays && timeToMinutes(leadTime) > timeToMinutes(deadlineTime)) {
                                            setLeadTime(deadlineTime);
                                        }
                                    }} />
                                </View>
                                {leadEnabled && (
                                    <View style={{ marginTop: 10 }}>
                                        <View style={[s.leadRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                                            <PressableOpacity accessibilityLabel="Decrease" onPress={() => {
                                                const nextLeadDays = Math.max(deadlineEnabled ? deadlineDays : 0, leadDays - 1);
                                                setLeadDays(nextLeadDays);
                                                if (deadlineEnabled && nextLeadDays === deadlineDays && timeToMinutes(leadTime) > timeToMinutes(deadlineTime)) {
                                                    setLeadTime(deadlineTime);
                                                }
                                            }} style={[s.stepperBtn, { backgroundColor: colors.brandSoft }]}>
                                                <Feather name="minus" size={18} color={colors.brand} />
                                            </PressableOpacity>
                                            <View style={s.leadCenter}>
                                                <Text style={[s.leadVal, { color: colors.textPrimary }]}>{leadDays}</Text>
                                                <Text style={[s.leadSub, { color: colors.textFaint }]}>days before</Text>
                                            </View>
                                            <PressableOpacity accessibilityLabel="Increase" onPress={() => setLeadDays(leadDays + 1)} style={[s.stepperBtn, { backgroundColor: colors.brandSoft }]}>
                                                <Feather name="plus" size={18} color={colors.brand} />
                                            </PressableOpacity>
                                        </View>
                                        <Text style={[s.fieldLabel, { color: colors.textFaint }]}>Time</Text>
                                        <PressableOpacity style={[s.dateFieldRow, { backgroundColor: colors.surface, borderColor: colors.border }]} onPress={openLeadTimePicker}>
                                            <Feather name="clock" size={16} color={colors.textFaint} style={{ marginRight: 10 }} />
                                            <Text style={[s.dateFieldText, { color: colors.textSecondary }]}>{leadTime}</Text>
                                            <Feather name={showLeadTimePicker ? "chevron-up" : "chevron-down"} size={16} color={colors.textFaint} style={{ marginLeft: "auto" }} />
                                        </PressableOpacity>
                                    </View>
                                )}
                            </View>

                            <View>
                                <View style={s.toggleRow}>
                                    <View style={s.toggleRowLabelWrap}>
                                        <Text style={[s.toggleRowLabel, { color: colors.textSecondary }]}>Latest time to RSVP</Text>
                                        <InfoBubble
                                            title="Latest time to RSVP"
                                            description={"This sets the cutoff for responding.\n\nIt's a number of days before the meetup, at a specific time.\n\nTurn it off to allow RSVPs right up until the meetup starts."}
                                        />
                                    </View>
                                    <ToggleSwitch value={deadlineEnabled} onValueChange={(v) => {
                                        setDeadlineEnabled(v);
                                        const nextDeadlineDays = v && leadEnabled && deadlineDays > leadDays ? leadDays : deadlineDays;
                                        if (nextDeadlineDays !== deadlineDays) setDeadlineDays(nextDeadlineDays);
                                        if (v && leadEnabled && nextDeadlineDays === leadDays && timeToMinutes(deadlineTime) < timeToMinutes(leadTime)) {
                                            setDeadlineTime(leadTime);
                                        }
                                    }} />
                                </View>
                                {deadlineEnabled && (
                                    <View style={{ marginTop: 10 }}>
                                        <View style={[s.leadRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                                            <PressableOpacity accessibilityLabel="Decrease" onPress={() => setDeadlineDays(Math.max(0, deadlineDays - 1))} style={[s.stepperBtn, { backgroundColor: colors.brandSoft }]}>
                                                <Feather name="minus" size={18} color={colors.brand} />
                                            </PressableOpacity>
                                            <View style={s.leadCenter}>
                                                <Text style={[s.leadVal, { color: colors.textPrimary }]}>{deadlineDays}</Text>
                                                <Text style={[s.leadSub, { color: colors.textFaint }]}>days before</Text>
                                            </View>
                                            <PressableOpacity accessibilityLabel="Increase" onPress={() => {
                                                const nextDeadlineDays = leadEnabled ? Math.min(leadDays, deadlineDays + 1) : deadlineDays + 1;
                                                setDeadlineDays(nextDeadlineDays);
                                                if (leadEnabled && nextDeadlineDays === leadDays && timeToMinutes(deadlineTime) < timeToMinutes(leadTime)) {
                                                    setDeadlineTime(leadTime);
                                                }
                                            }} style={[s.stepperBtn, { backgroundColor: colors.brandSoft }]}>
                                                <Feather name="plus" size={18} color={colors.brand} />
                                            </PressableOpacity>
                                        </View>
                                        <Text style={[s.fieldLabel, { color: colors.textFaint }]}>Time</Text>
                                        <PressableOpacity style={[s.dateFieldRow, { backgroundColor: colors.surface, borderColor: colors.border }]} onPress={openDeadlineTimePicker}>
                                            <Feather name="clock" size={16} color={colors.textFaint} style={{ marginRight: 10 }} />
                                            <Text style={[s.dateFieldText, { color: colors.textSecondary }]}>{deadlineTime}</Text>
                                            <Feather name={showDeadlineTimePicker ? "chevron-up" : "chevron-down"} size={16} color={colors.textFaint} style={{ marginLeft: "auto" }} />
                                        </PressableOpacity>
                                    </View>
                                )}
                            </View>
                        </View>
                    )}
                </ScrollView>

                <View style={[s.screenFooter, { borderTopColor: colors.border, backgroundColor: colors.surface }]}>
                    {!hasChanged && (
                        <Text style={[s.noChangeHint, { color: colors.textFaint }]}>No changes yet</Text>
                    )}
                    <PressableOpacity
                        style={[s.primaryBtn, { backgroundColor: colors.brand }, (!hasChanged || isSaving) && { backgroundColor: disabledBtnBg }]}
                        onPress={handleSave}
                        disabled={!hasChanged || isSaving}
                    >
                        {isSaving
                            ? <ActivityIndicator color="#fff" size="small" />
                            : <><Text style={s.primaryBtnText}>Save Changes</Text><Feather name="check" size={18} color="#fff" style={{ marginLeft: 6 }} /></>
                        }
                    </PressableOpacity>
                </View>
            </View>

            {showLeadTimePicker && (
                <NativeTimePicker value={leadTime} onChange={(t) => {
                    const capped = deadlineEnabled && leadDays === deadlineDays && timeToMinutes(t) > timeToMinutes(deadlineTime);
                    if (capped) {
                        Alert.alert(
                            "Earliest RSVP time must be before the latest RSVP time",
                            `• Both are ${leadDays} day${leadDays === 1 ? '' : 's'} before the meetup\n• Earliest time can't be later than ${deadlineTime}\n• Earliest time set to ${deadlineTime}`
                        );
                    }
                    setLeadTime(capped ? deadlineTime : t);
                }} onClose={() => setShowLeadTimePicker(false)} />
            )}

            {showDeadlineTimePicker && (
                <NativeTimePicker value={deadlineTime} onChange={(t) => {
                    const capped = leadEnabled && deadlineDays === leadDays && timeToMinutes(t) < timeToMinutes(leadTime);
                    if (capped) {
                        Alert.alert(
                            "Latest RSVP time must be after the earliest RSVP time",
                            `• Both are ${deadlineDays} day${deadlineDays === 1 ? '' : 's'} before the meetup\n• Latest time can't be earlier than ${leadTime}\n• Latest time set to ${leadTime}`
                        );
                    }
                    setDeadlineTime(capped ? leadTime : t);
                }} onClose={() => setShowDeadlineTimePicker(false)} />
            )}
        </SafeAreaView>
    );
};

export default EditJitScreen;

// ─── Styles ───────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
    safe: { flex: 1, backgroundColor: "#F9FAFB" },
    screen: { flex: 1 },
    screenHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingTop: 8, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: "#F3F4F6", backgroundColor: "#fff" },
    headerTitle: { fontSize: 17, fontWeight: "800", color: "#111827" },
    screenSub: { fontSize: 13, color: "#9CA3AF", marginBottom: 8, marginTop: 12, lineHeight: 18 },
    screenFooter: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", paddingHorizontal: 24, paddingVertical: 16, borderTopWidth: 1, borderTopColor: "#F3F4F6", backgroundColor: "#fff", gap: 12 },
    noChangeHint: { fontSize: 13, color: "#9CA3AF", fontWeight: "600" },
    iconBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
    primaryBtn: { flexDirection: "row", alignItems: "center", backgroundColor: "#4A90E2", paddingHorizontal: 24, paddingVertical: 14, borderRadius: 14 },
    primaryBtnDisabled: { backgroundColor: "#93C5FD" },
    primaryBtnText: { color: "#fff", fontWeight: "800", fontSize: 15 },
    fieldLabel: { fontSize: 11, fontWeight: "800", color: "#9CA3AF", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8, marginTop: 16 },
    boolRow: { flexDirection: "row", gap: 10 },
    boolBtn: { flex: 1, paddingVertical: 11, borderRadius: 10, borderWidth: 1.5, borderColor: "#E5E7EB", alignItems: "center", backgroundColor: "#fff" },
    boolBtnActive: { borderColor: "#4A90E2", backgroundColor: "#EEF6FF" },
    boolBtnText: { fontSize: 14, fontWeight: "700", color: "#6B7280" },
    boolBtnTextActive: { color: "#4A90E2" },
    toggleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
    toggleRowLabelWrap: { flexDirection: "row", alignItems: "center", gap: 8, flex: 1, marginRight: 12 },
    toggleRowLabel: { fontSize: 14, fontWeight: "700", color: "#374151" },
    leadRow: { flexDirection: "row", alignItems: "center", backgroundColor: "#fff", borderRadius: 14, borderWidth: 1, borderColor: "#E5E7EB", paddingHorizontal: 12, paddingVertical: 10, gap: 8 },
    stepperBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#EEF6FF", alignItems: "center", justifyContent: "center" },
    leadCenter: { alignItems: "center", minWidth: 60 },
    leadVal: { fontSize: 22, fontWeight: "900", color: "#111827" },
    leadSub: { fontSize: 10, color: "#9CA3AF", fontWeight: "600", textTransform: "uppercase" },
    dateFieldRow: { flexDirection: "row", alignItems: "center", backgroundColor: "#fff", borderRadius: 12, borderWidth: 1, borderColor: "#E5E7EB", paddingHorizontal: 14, paddingVertical: 13, marginBottom: 4 },
    dateFieldText: { fontSize: 15, color: "#374151", fontWeight: "500" },
});
