import { Stack, useRouter } from 'expo-router';
import React from 'react';
import { PressableOpacity } from '@/components/ui/PressableOpacity';
import { Feather } from '@expo/vector-icons';
import { useThemeColors } from '@/contexts/AppearanceContext';

const CreateGroupLayout = () => {
    const router = useRouter();
    const colors = useThemeColors();

    return (
        <Stack screenOptions={{ contentStyle: { backgroundColor: colors.background } }}>
            <Stack.Screen
                name="index"
                options={{
                    presentation: 'card', // full-screen push
                headerShown: false,
                gestureEnabled: false, // disable swipe-back
                    headerLeft: () => (
                        <PressableOpacity accessibilityLabel="Close" onPress={() => router.back()} style={{ marginLeft: 10 }}>
                            <Feather name="x" size={24} color={colors.brand} />
                        </PressableOpacity>
                    ),
                }}
            />
        </Stack>
    );
};

export default CreateGroupLayout;