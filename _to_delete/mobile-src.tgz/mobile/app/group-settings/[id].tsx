import React, { useEffect, useRef, useState, useMemo } from 'react';
import { useWindowInsets } from '@/contexts/WindowInsetsContext';
import { requireOnline } from '@/utils/offlineState';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
  ActivityIndicator,
  Modal,
  Pressable,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Image,
  FlatList,
  Animated,
  Easing
} from 'react-native';
import { PressableOpacity } from '@/components/ui/PressableOpacity';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useAndroidBack } from '@/hooks/useAndroidBack';
import { useAuth } from '@clerk/expo';
import { Feather } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useGetGroupDetails } from '@/hooks/useGetGroupDetails';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { User, useApiClient, userApi, groupApi } from '@/utils/api';
import { usePremium } from '@/hooks/usePremium';
import { getErrorMessage } from '@/utils/networkError';
import { formatSchedule } from '@/utils/schedule';
import { useDeleteGroup } from '@/hooks/useDeleteGroup';
import { useLeaveGroup } from '@/hooks/useLeaveGroup';
import { pickImageUri, uploadImageFromUri, deleteStorageImage } from '@/utils/uploadImage';
import { broadcastGroupUpdate, broadcastMeetupUpdate } from '@/utils/groupRealtime';
import { getUserDisplayName } from '@/utils/groupDisplay';
import { GroupAvatar } from '@/components/GroupAvatar';
import { LoadingAnimation } from '@/components/LoadingAnimation';
import { useAppearance, useThemeColors } from '@/contexts/AppearanceContext';
import { toast } from '@/contexts/ToastContext';

// Access restricted to the group owner and designated moderators
const GroupSettings = () => {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const api = useApiClient();
  const { isPremium } = usePremium();
  const queryClient = useQueryClient();
  const insets = useSafeAreaInsets();
  // Real top inset; 0 while the offline banner (above the navigator) already covers it.
  const contentTopInset = useSafeAreaInsets().top;
  // Full-screen modals below cover the offline banner too, so they pad by the real inset.
  const windowInsets = useWindowInsets();
  const colors = useThemeColors();
  const { scheme } = useAppearance();
  const isDark = scheme === 'dark';

  const { getToken } = useAuth();
  const { data: group, isLoading: isLoadingGroup } = useGetGroupDetails(id);
  const { data: currentUser, isLoading: isLoadingUser } = useQuery<User, Error>({
    queryKey: ['currentUser'],
    queryFn: () => userApi.getCurrentUser(api),
  });

  // --- Termination Hooks ---
  const { mutate: deleteGroup } = useDeleteGroup();
  const { mutate: leaveGroup } = useLeaveGroup();

  // --- Top-level navigation between Settings home / Edit Group / Edit Schedule ---
  const [view, setView] = useState<'main' | 'group' | 'schedules'>('main');
  // Android back from a sub-page returns to the main settings page, like the on-screen arrow.
  useAndroidBack(view !== 'main', () => setView('main'));

  // --- State for Edit Modals ---
  const [isImageModalVisible, setIsImageModalVisible] = useState(false);
  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [isConfirmingImage, setIsConfirmingImage] = useState(false);

  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState("");
  const [isSavingName, setIsSavingName] = useState(false);
  const [isCelebratingName, setIsCelebratingName] = useState(false);
  const [celebrationName, setCelebrationName] = useState("");
  const letterAnimsRef = useRef<Animated.Value[]>([]);
  const nameFlyAnim = useRef(new Animated.Value(0)).current;
  const heartRiseAnim = useRef(new Animated.Value(0)).current;
  const heartPopScale = useRef(new Animated.Value(1)).current;

  // --- State for Moderator Management ---
  const [isEditingMods, setIsEditingMods] = useState(false);
  const [selectedModIds, setSelectedModIds] = useState<string[]>([]);
  const [isSavingMods, setIsSavingMods] = useState(false);

  // --- State for Member Management ---
  const [isEditingMembers, setIsEditingMembers] = useState(false);
  const [isRemovingMemberId, setIsRemovingMemberId] = useState<string | null>(null);

  // --- State for Ownership Transfer ---
  const [isTransferModalVisible, setIsTransferModalVisible] = useState(false);
  const [isTransferringId, setIsTransferringId] = useState<string | null>(null);

  // --- Robust Permission Logic ---
  const isUserOwner = useMemo(() => {
    if (!currentUser || !group) return false;
    const ownerId = (group.owner as any)?._id || group.owner;
    return currentUser._id.toString() === ownerId.toString();
  }, [currentUser, group]);

  const isUserMod = useMemo(() => {
    if (!currentUser || !group) return false;
    const userId = currentUser._id.toString();
    return group.moderators?.some((m: any) => (m?._id || m).toString() === userId);
  }, [currentUser, group]);

  const canAccessSettings = useMemo(() => {
    return isUserOwner || isUserMod;
  }, [isUserOwner, isUserMod]);

  const activeSchedules = useMemo(
    () => (group?.schedules ?? []).filter(sch => sch.active !== false),
    [group?.schedules]
  );
  const MAX_ACTIVE_SCHEDULES = 5;
  const canAddSchedule = activeSchedules.length < MAX_ACTIVE_SCHEDULES;

  // --- ACCESS CONTROL GUARD ---
  useEffect(() => {
    if (!isLoadingGroup && !isLoadingUser && group && currentUser) {
      if (!canAccessSettings) {
        Alert.alert(
          "Permission Denied",
          "Only owners and moderators can access group settings."
        );
        router.back();
      }
    }
  }, [group, currentUser, isLoadingGroup, isLoadingUser, canAccessSettings]);

  // Pastel icon-chip backgrounds adapt by scheme while keeping the same hue family
  const chipBlue = isDark ? '#1A2A42' : '#EFF6FF';
  const chipCyan = isDark ? '#123338' : '#ECFEFF';
  const chipOrange = isDark ? '#3A2712' : '#FFF7ED';
  const chipPurple = isDark ? '#241B3D' : '#F5F3FF';
  const chipRed = isDark ? '#3B1E1E' : '#FEF2F2';
  const chipIndigo = isDark ? '#1E2340' : '#EEF2FF';
  const chipPink = isDark ? '#3A1B2E' : '#FDF2F8';
  const chipGreen = isDark ? '#12301F' : '#ECFDF5';

  const settingsOptions = [
    { id: 'image', label: 'Edit Group Photo', icon: 'camera', color: colors.brand, bg: chipBlue },
    { id: 'name', label: 'Edit Group Name', icon: 'type', color: '#3B82F6', bg: chipBlue },
    { id: 'mods', label: 'Edit Moderators', icon: 'shield', color: '#06B6D4', bg: chipCyan },
    { id: 'members', label: 'Remove Members', icon: 'user-minus', color: '#F97316', bg: chipOrange },
    ...(isUserOwner ? [{ id: 'transfer', label: 'Transfer Ownership', icon: 'repeat', color: '#8B5CF6', bg: chipPurple }] : []),
  ];

  const mainOptions = [
    { id: 'group', label: 'Edit Group Info', icon: 'edit-2', color: colors.brand, bg: chipBlue },
    { id: 'schedules', label: 'Edit Meetup Schedules', icon: 'calendar', color: '#6366F1', bg: chipIndigo },
    { id: 'invite', label: 'Invite Link & Code', icon: 'link', color: '#14B8A6', bg: chipCyan },
    { id: 'reactions', label: 'RSVP Reactions', icon: 'smile', color: '#EC4899', bg: chipPink },
    { id: 'stats', label: 'Stats & Attendance', icon: 'bar-chart-2', color: '#10B981', bg: chipGreen },
    { id: 'rankings', label: 'Strength Rankings', icon: 'list', color: '#F59E0B', bg: chipOrange },
    { id: 'terminate', label: isUserOwner ? 'Delete Group' : 'Leave Group', icon: isUserOwner ? 'trash-2' : 'log-out', color: colors.danger, bg: chipRed, destructive: true },
  ];

  const handleOptionPress = (optionId: string) => {
    if (!id) return;

    switch (optionId) {
      case 'group':
        setView('group');
        break;
      case 'schedules':
        setView('schedules');
        break;
      case 'reactions':
        router.push({ pathname: '/group-rsvp-responses/[id]', params: { id } });
        break;
      case 'stats':
        router.push({ pathname: '/group-stats/[id]', params: { id } });
        break;
      case 'invite':
        router.push({ pathname: '/group-invite/[id]', params: { id } });
        break;
      case 'rankings':
        router.push({ pathname: '/group-rankings/[id]', params: { id } });
        break;
      case 'image':
        handleOpenImageModal();
        break;
      case 'name':
        setTempName(group?.name || "");
        setIsEditingName(true);
        break;
      case 'mods':
        const currentModIds = (group?.moderators || []).map((m: any) =>
            typeof m === 'string' ? m : m._id
        );
        setSelectedModIds(currentModIds);
        setIsEditingMods(true);
        break;
      case 'members':
        setIsEditingMembers(true);
        break;
      case 'transfer':
        setIsTransferModalVisible(true);
        break;
      case 'terminate':
        if (isUserOwner) handleConfirmDelete();
        else handleConfirmLeave();
        break;
      default:
        break;
    }
  };

  const imageModalRotation = useRef(new Animated.Value(0)).current;

  const handleOpenImageModal = () => {
    setPreviewUri(null);
    setIsImageModalVisible(true);
    imageModalRotation.setValue(0);
    Animated.sequence([
      Animated.timing(imageModalRotation, { toValue: -6, duration: 90, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      Animated.timing(imageModalRotation, { toValue: 5, duration: 110, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.timing(imageModalRotation, { toValue: -3, duration: 100, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.timing(imageModalRotation, { toValue: 1.5, duration: 100, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.timing(imageModalRotation, { toValue: 0, duration: 100, easing: Easing.out(Easing.quad), useNativeDriver: true }),
    ]).start();
  };

  const imageModalRotateStyle = {
    transform: [
      {
        rotate: imageModalRotation.interpolate({
          inputRange: [-6, 6],
          outputRange: ['-6deg', '6deg'],
        }),
      },
    ],
  };

  const avatarPopScale = useRef(new Animated.Value(1)).current;

  const handlePickNewImage = async () => {
    let uri: string | null = null;
    try {
      uri = await pickImageUri(api);
    } catch {
      Alert.alert("Couldn't use that photo", "Couldn't read that photo. Try another one.");
      return;
    }
    if (uri) {
      setPreviewUri(uri);
      avatarPopScale.setValue(1);
      Animated.sequence([
        Animated.delay(200),
        Animated.timing(avatarPopScale, { toValue: 1.18, duration: 2000, easing: Easing.out(Easing.exp), useNativeDriver: true }),
        Animated.timing(avatarPopScale, { toValue: 1, duration: 200, easing: Easing.in(Easing.cubic), useNativeDriver: true }),
        Animated.timing(avatarPopScale, { toValue: 1.04, duration: 70, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(avatarPopScale, { toValue: 0.98, duration: 70, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(avatarPopScale, { toValue: 1.01, duration: 60, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(avatarPopScale, { toValue: 1, duration: 60, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      ]).start();
    }
  };

  const handleConfirmImage = async () => {
    if (!id || !previewUri) return;
    try {
      setIsConfirmingImage(true);
      const token = await getToken({ template: 'supabase' });
      if (!token) throw new Error('No auth token');

      const oldImageUrl = group?.image;
      const newFilePath = `${id}/cover.jpg`;
      const newUrl = await uploadImageFromUri(previewUri, 'group-images', newFilePath, token);

      await groupApi.updateGroup(api, { groupId: id, image: newUrl });

      // Only delete the old file if it's a different path — same path means upsert already overwrote it
      if (oldImageUrl) {
        const marker = `/storage/v1/object/public/group-images/`;
        const oldPath = oldImageUrl.slice(oldImageUrl.indexOf(marker) + marker.length).split('?')[0];
        if (oldPath !== newFilePath) {
          deleteStorageImage(oldImageUrl, 'group-images', token).catch(() => {});
        }
      }

      queryClient.setQueryData(['groupDetails', id], (old: any) =>
        old ? { ...old, image: newUrl } : old
      );
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      queryClient.invalidateQueries({ queryKey: ['meetups'] });
      broadcastGroupUpdate(getToken, id);
      broadcastMeetupUpdate(getToken, id);
      setIsImageModalVisible(false);
    } catch (error) {
      Alert.alert('Error', getErrorMessage(error, 'Could not update group photo. Please try again.'));
    } finally {
      setIsConfirmingImage(false);
    }
  };

  const playNameCelebration = (name: string) => {
    letterAnimsRef.current = name.split('').map(() => new Animated.Value(0));
    nameFlyAnim.setValue(0);
    heartRiseAnim.setValue(0);
    heartPopScale.setValue(1);
    setCelebrationName(name);
    setIsCelebratingName(true);

    const waveAnimations = letterAnimsRef.current.map((letterAnim, i) =>
      Animated.sequence([
        Animated.delay(i * 45),
        Animated.timing(letterAnim, { toValue: 1, duration: 180, easing: Easing.out(Easing.quad), useNativeDriver: false }),
        Animated.timing(letterAnim, { toValue: 0, duration: 180, easing: Easing.in(Easing.quad), useNativeDriver: false }),
      ])
    );

    Animated.sequence([
      Animated.parallel(waveAnimations),
      Animated.parallel([
        Animated.timing(nameFlyAnim, { toValue: -260, duration: 450, easing: Easing.in(Easing.cubic), useNativeDriver: true }),
        Animated.sequence([
          Animated.timing(heartRiseAnim, { toValue: 1, duration: 450, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
          Animated.timing(heartPopScale, { toValue: 1.18, duration: 500, easing: Easing.out(Easing.exp), useNativeDriver: true }),
          Animated.timing(heartPopScale, { toValue: 1, duration: 50, easing: Easing.in(Easing.cubic), useNativeDriver: true }),
          Animated.timing(heartPopScale, { toValue: 1.04, duration: 18, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(heartPopScale, { toValue: 0.98, duration: 18, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(heartPopScale, { toValue: 1.01, duration: 15, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(heartPopScale, { toValue: 1, duration: 15, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        ]),
      ]),
    ]).start(() => {
      setIsEditingName(false);
      setIsCelebratingName(false);
      setCelebrationName("");
    });
  };

  const handleSaveName = async () => {
    if (!id || !tempName.trim()) return;
    if (tempName === group?.name) {
        setIsEditingName(false);
        return;
    }

    setIsSavingName(true);
    try {
        await groupApi.updateGroup(api, { groupId: id, name: tempName.trim() });
        await Promise.all([
            queryClient.invalidateQueries({ queryKey: ['groupDetails', id] }),
            queryClient.invalidateQueries({ queryKey: ['groups'] }),
            queryClient.invalidateQueries({ queryKey: ['meetups'] })
        ]);
        broadcastGroupUpdate(getToken, id);
        broadcastMeetupUpdate(getToken, id);
        playNameCelebration(tempName.trim());
    } catch (error: any) {
        Alert.alert("Error", getErrorMessage(error, "Failed to update group name."));
    } finally {
        setIsSavingName(false);
    }
  };

  // --- MODERATOR LOGIC ---
  const handleToggleModSelection = (userId: string) => {
    setSelectedModIds(prev =>
        prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  const handleSaveModerators = async () => {
    if (!id) return;
    setIsSavingMods(true);
    try {
        await groupApi.updateModerators(api, {
            groupId: id,
            moderatorIds: selectedModIds
        });
        await queryClient.invalidateQueries({ queryKey: ['groupDetails', id] });
        // Meetups embed a snapshot of the group (for permission checks like
        // canManage) that only refreshes via delta-sync keyed off the meetup's
        // own updatedAt — the backend bumps that for upcoming meetups on a
        // moderator change specifically so this catches it.
        queryClient.invalidateQueries({ queryKey: ['meetups'] });
        broadcastGroupUpdate(getToken, id);
        setIsEditingMods(false);
        toast.success("Moderator list updated.");
    } catch (error: any) {
        Alert.alert("Error", getErrorMessage(error, "Failed to update moderators."));
    } finally {
        setIsSavingMods(false);
    }
  };

  // --- MEMBER REMOVAL LOGIC ---
  const handleRemoveMemberPress = (member: User) => {
    if (!requireOnline('remove a member')) return;
    Alert.alert(
      "Remove Member",
      `Are you sure you want to remove ${getUserDisplayName(member)} from the group?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: () => performMemberRemoval(member._id)
        }
      ]
    );
  };

  const performMemberRemoval = async (memberId: string) => {
    if (!id) return;
    setIsRemovingMemberId(memberId);
    try {
        await groupApi.removeMember(api, { groupId: id, memberIdToRemove: memberId });
        await Promise.all([
            queryClient.invalidateQueries({ queryKey: ['groupDetails', id] }),
            queryClient.invalidateQueries({ queryKey: ['groups'] }),
            queryClient.invalidateQueries({ queryKey: ['meetups'] })
        ]);
        broadcastGroupUpdate(getToken, id);
        broadcastMeetupUpdate(getToken, id);
    } catch (error: any) {
        Alert.alert("Error", getErrorMessage(error, "Failed to remove member."));
    } finally {
        setIsRemovingMemberId(null);
    }
  };

  // --- OWNERSHIP TRANSFER LOGIC ---
  const handleTransferPress = (member: User) => {
    if (!requireOnline('transfer ownership')) return;
    Alert.alert(
      "Transfer Ownership",
      `Are you sure you want to make ${getUserDisplayName(member)} the new owner? You will become a moderator.` +
        // Premium is tied to the owner's subscription, so it does not follow the group.
        (isPremium
          ? `\n\nHeads up: this group's Premium features are covered by your subscription. Once ${getUserDisplayName(member)} is the owner, they will be paused for this group unless the new owner has their own Premium subscription. Your data is kept.`
          : ''),
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Transfer",
          style: "destructive",
          onPress: () => performTransfer(member._id),
        },
      ]
    );
  };

  const performTransfer = async (newOwnerId: string) => {
    if (!id) return;
    setIsTransferringId(newOwnerId);
    try {
      await groupApi.transferOwnership(api, { groupId: id, newOwnerId });
      await queryClient.invalidateQueries({ queryKey: ['groupDetails', id] });
      queryClient.invalidateQueries({ queryKey: ['meetups'] });
      broadcastGroupUpdate(getToken, id);
      setIsTransferModalVisible(false);
      toast.success("Ownership transferred.");
    } catch (error: any) {
      Alert.alert("Error", getErrorMessage(error, "Failed to transfer ownership."));
    } finally {
      setIsTransferringId(null);
    }
  };

  // --- TERMINATION LOGIC ---

  const handleConfirmDelete = () => {
    if (!requireOnline('delete this group')) return;
    // Step 1: Standard Deletion Alert
    Alert.alert(
      "Delete Group",
      `Are you sure you want to permanently delete "${group?.name}"?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            // Step 2: Critical Recovery Warning
            Alert.alert(
              "Final Confirmation",
              "Your group cannot be recovered if deleted. Are you sure?",
              [
                { text: "Cancel", style: "cancel" },
                {
                  text: "Yes, I am sure",
                  style: "destructive",
                  onPress: () => {
                    deleteGroup({ groupId: id! }, {
                      onSuccess: () => {
                        queryClient.invalidateQueries({ queryKey: ['groups'] });
                        router.dismissTo('/(tabs)/groups');
                      }
                    });
                  }
                }
              ]
            );
          }
        }
      ]
    );
  };

  const handleConfirmLeave = () => {
    if (!requireOnline('leave this group')) return;
    Alert.alert("Leave Group", "Are you sure you want to leave this group?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Leave",
        style: "destructive",
        onPress: () => {
          leaveGroup({ groupId: id! }, {
            onSuccess: () => {
              queryClient.invalidateQueries({ queryKey: ['groups'] });
              router.dismissTo('/(tabs)/groups');
            },
          });
        }
      },
    ]);
  };

  if (isLoadingGroup || isLoadingUser) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <LoadingAnimation />
      </View>
    );
  }

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.background, paddingTop: contentTopInset }]}
      edges={['left', 'right', 'bottom']}
    >
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        {view === 'main' ? (
          <PressableOpacity accessibilityLabel="Close" onPress={() => router.back()} style={styles.closeButton}>
            <Feather name="x" size={28} color={colors.textSecondary} />
          </PressableOpacity>
        ) : (
          <PressableOpacity accessibilityLabel="Go back" onPress={() => setView('main')} style={styles.closeButton}>
            <Feather name="arrow-left" size={26} color={colors.textSecondary} />
          </PressableOpacity>
        )}
        <Text style={[styles.headerTitle, { color: colors.textPrimary }]}>
          {view === 'main' ? 'Group Settings' : view === 'group' ? 'Edit Group Info' : 'Edit Meetup Schedules'}
        </Text>
        <View style={{ width: 44 }} />
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {view === 'main' && (
          <View style={styles.optionsContainer}>
            {mainOptions.map((option) => (
              <PressableOpacity
                key={option.id}
                style={[styles.optionButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
                activeOpacity={0.7}
                onPress={() => handleOptionPress(option.id)}
              >
                <View style={styles.optionLeft}>
                  <View style={[styles.iconContainer, { backgroundColor: option.bg }]}>
                    <Feather name={option.icon as any} size={20} color={option.color} />
                  </View>
                  <Text style={[styles.optionLabel, { color: colors.textPrimary }, option.destructive && { color: colors.danger }]}>
                    {option.label}
                  </Text>
                </View>
                {!option.destructive && <Feather name="chevron-right" size={18} color={colors.textFaint} />}
              </PressableOpacity>
            ))}
          </View>
        )}

        {view === 'group' && (
          <View style={styles.optionsContainer}>
            {settingsOptions.map((option) => (
              <PressableOpacity
                key={option.id}
                style={[styles.optionButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
                activeOpacity={0.7}
                onPress={() => handleOptionPress(option.id)}
              >
                <View style={styles.optionLeft}>
                  {option.id === 'image' ? (
                    <View style={{ marginRight: 16 }}>
                      <GroupAvatar name={group?.name ?? ''} imageUrl={group?.image} size={40} borderRadius={11} />
                    </View>
                  ) : (
                    <View style={[styles.iconContainer, { backgroundColor: option.bg }]}>
                      <Feather name={option.icon as any} size={20} color={option.color} />
                    </View>
                  )}
                  <View style={{ flexShrink: 1 }}>
                    <Text style={[styles.optionLabel, { color: colors.textPrimary }, (option as any).destructive && { color: colors.danger }]}>
                      {option.label}
                    </Text>
                    {option.id === 'image' && (
                      <Text style={[styles.optionSubLabel, { color: colors.textFaint }]}>
                        {group?.image ? 'Tap to change' : 'No photo set'}
                      </Text>
                    )}
                    {option.id === 'name' && (
                      <Text style={[styles.optionSubLabel, { color: colors.textFaint }]} numberOfLines={1}>
                        {group?.name || '—'}
                      </Text>
                    )}
                    {option.id === 'mods' && (
                      <Text style={[styles.optionSubLabel, { color: colors.textFaint }]}>
                        {(group?.moderators?.length || 0)} moderators assigned
                      </Text>
                    )}
                    {option.id === 'members' && (
                      <Text style={[styles.optionSubLabel, { color: colors.textFaint }]}>
                        {(group?.members?.length || 0)} total members
                      </Text>
                    )}
                  </View>
                </View>
                <Feather name="chevron-right" size={18} color={colors.textFaint} />
              </PressableOpacity>
            ))}
          </View>
        )}

        {view === 'schedules' && (
          <View style={styles.optionsContainer}>
            {activeSchedules.map((sch) => (
              <View key={sch._id} style={[styles.optionButton, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <PressableOpacity
                  style={styles.optionLeft}
                  activeOpacity={0.7}
                  onPress={() => router.push({ pathname: '/group-edit-schedule/[id]', params: { id: id!, scheduleId: sch._id } })}
                >
                  <View style={[styles.iconContainer, { backgroundColor: chipIndigo }]}>
                    <Feather name="calendar" size={20} color="#6366F1" />
                  </View>
                  <View style={{ flexShrink: 1 }}>
                    <Text style={[styles.optionLabel, { color: colors.textPrimary }]}>{sch.name}</Text>
                    <Text style={[styles.optionSubLabel, { color: colors.textFaint }]} numberOfLines={1}>{formatSchedule(sch)}</Text>
                  </View>
                </PressableOpacity>
                <PressableOpacity accessibilityLabel="Notifications"
                  style={{ padding: 6 }}
                  onPress={() => router.push({ pathname: '/group-edit-jit/[id]', params: { id: id!, scheduleId: sch._id } })}
                >
                  <Feather name="bell" size={18} color="#F59E0B" />
                </PressableOpacity>
              </View>
            ))}
            {canAddSchedule && (
              <PressableOpacity
                style={[styles.optionButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
                activeOpacity={0.7}
                onPress={() => router.push({ pathname: '/group-edit-schedule/[id]', params: { id: id!, scheduleId: 'new' } })}
              >
                <View style={styles.optionLeft}>
                  <View style={[styles.iconContainer, { backgroundColor: chipIndigo }]}>
                    <Feather name="plus" size={20} color="#6366F1" />
                  </View>
                  <Text style={[styles.optionLabel, { color: colors.textPrimary }]}>Add Schedule</Text>
                </View>
              </PressableOpacity>
            )}
          </View>
        )}

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.textFaint }]}>
            Only group moderators and owners can view or modify these settings.
          </Text>
        </View>
      </ScrollView>

      {/* Edit Group Photo Modal */}
      <Modal
        visible={isImageModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setIsImageModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setIsImageModalVisible(false)}>
          <Animated.View style={imageModalRotateStyle}>
            <Pressable onPress={() => {}} style={[styles.modalContent, styles.imageModalContent, { backgroundColor: colors.surface }]}>
              <Text style={[styles.modalTitle, { color: colors.textPrimary }]}>Group Photo</Text>

              <PressableOpacity accessibilityLabel="Take a photo" onPress={handlePickNewImage} disabled={isConfirmingImage} style={styles.imageModalAvatarWrap}>
                <Animated.View style={{ transform: [{ scale: avatarPopScale }] }}>
                  <GroupAvatar
                    name={group?.name ?? ''}
                    imageUrl={previewUri ?? group?.image}
                    size={120}
                    borderRadius={28}
                  />
                  <View style={[styles.imageModalCameraBadge, { backgroundColor: colors.brand, borderColor: colors.surface }]}>
                    <Feather name="camera" size={16} color="#fff" />
                  </View>
                </Animated.View>
              </PressableOpacity>

              {previewUri ? (
                <PressableOpacity
                  style={[styles.confirmBtn, { backgroundColor: colors.brand }]}
                  onPress={handleConfirmImage}
                  disabled={isConfirmingImage}
                >
                  {isConfirmingImage
                    ? <ActivityIndicator color="#fff" size="small" />
                    : <Text style={styles.confirmBtnText}>Confirm</Text>}
                </PressableOpacity>
              ) : (
                <PressableOpacity
                  style={[styles.confirmBtn, { backgroundColor: colors.backgroundAlt }]}
                  onPress={() => setIsImageModalVisible(false)}
                >
                  <Text style={[styles.modalBtnTextCancel, { color: colors.textSecondary }]}>Cancel</Text>
                </PressableOpacity>
              )}
            </Pressable>
          </Animated.View>
        </Pressable>
      </Modal>

      {/* Edit Name Modal */}
      <Modal visible={isEditingName} transparent animationType="fade" onRequestClose={() => setIsEditingName(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.modalOverlay}>
            <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
                {isCelebratingName ? (
                    <View style={styles.nameCelebrationStage}>
                        <Animated.View
                            style={[
                                styles.nameCelebrationHeart,
                                {
                                    transform: [
                                        { translateY: heartRiseAnim.interpolate({ inputRange: [0, 1], outputRange: [150, 0] }) },
                                        { scale: heartPopScale },
                                    ],
                                },
                            ]}
                        >
                            <Text style={styles.nameCelebrationHeartText}>❤️</Text>
                        </Animated.View>
                        <Animated.View style={[styles.nameCelebrationNameRow, { transform: [{ translateY: nameFlyAnim }] }]}>
                            {celebrationName.split('').map((char, i) => (
                                <Animated.Text
                                    key={`${char}-${i}`}
                                    style={[
                                        styles.nameCelebrationLetter,
                                        {
                                            transform: [{
                                                translateY: letterAnimsRef.current[i]?.interpolate({ inputRange: [0, 1], outputRange: [0, -14] }) ?? 0,
                                            }],
                                            color: letterAnimsRef.current[i]?.interpolate({ inputRange: [0, 1], outputRange: [colors.textPrimary, '#4FD1C5'] }) ?? colors.textPrimary,
                                        },
                                    ]}
                                >
                                    {char === ' ' ? ' ' : char}
                                </Animated.Text>
                            ))}
                        </Animated.View>
                    </View>
                ) : (
                    <>
                        <Text style={[styles.modalTitle, { color: colors.textPrimary }]}>Edit Group Name</Text>
                        <TextInput
                          style={[styles.modalInput, { backgroundColor: colors.backgroundAlt, color: colors.textPrimary, borderColor: colors.border }]}
                          value={tempName}
                          onChangeText={setTempName}
                          placeholder="Enter group name"
                          placeholderTextColor={colors.placeholder}
                          autoFocus
                          maxLength={50}
                          selectTextOnFocus
                        />
                        <View style={styles.modalButtons}>
                            <PressableOpacity style={[styles.modalBtn, { backgroundColor: colors.backgroundAlt }]} onPress={() => setIsEditingName(false)}><Text style={[styles.modalBtnTextCancel, { color: colors.textSecondary }]}>Cancel</Text></PressableOpacity>
                            <PressableOpacity style={[styles.modalBtn, styles.modalBtnSave]} onPress={handleSaveName} disabled={isSavingName || !tempName.trim()}>
                                {isSavingName ? <ActivityIndicator size="small" color="white" /> : <Text style={styles.modalBtnTextSave}>Save</Text>}
                            </PressableOpacity>
                        </View>
                    </>
                )}
            </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Edit Moderators Modal */}
      <Modal
        visible={isEditingMods}
        transparent={false}
        animationType="slide"
        onRequestClose={() => setIsEditingMods(false)}
      >
        <View style={[styles.fullModalContainer, { backgroundColor: colors.background, paddingTop: windowInsets.top }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <PressableOpacity onPress={() => setIsEditingMods(false)} style={styles.headerIconButton}>
              <Feather name="x" size={24} color={colors.textSecondary} />
            </PressableOpacity>
            <Text style={[styles.modalTitleLarge, { color: colors.textPrimary }]}>Manage Moderators</Text>
            <PressableOpacity onPress={handleSaveModerators} disabled={isSavingMods} style={styles.headerIconButton}>
                {isSavingMods ? <ActivityIndicator size="small" color={colors.brand} /> : <Text style={[styles.saveBtnText, { color: colors.brand }]}>Save</Text>}
            </PressableOpacity>
          </View>

          <FlatList
            data={group?.members}
            keyExtractor={(item) => item._id}
            contentContainerStyle={{ padding: 20 }}
            ListHeaderComponent={() => (
              <Text style={[styles.modalSubtitleLeft, { color: colors.textMuted }]}>
                Only the group owner can assign moderators. Moderators can edit group settings, schedules, and manage meetups.
              </Text>
            )}
            renderItem={({ item }) => {
              const mId = item._id.toString();
              const groupOwnerId = ((group?.owner as any)?._id || group?.owner || "").toString();
              const isOwner = mId === groupOwnerId;
              const isSelected = selectedModIds.includes(mId);

              return (
                <PressableOpacity
                  style={[styles.selectMemberRow, { backgroundColor: colors.backgroundAlt }, isSelected && !isOwner && { backgroundColor: colors.brand }]}
                  onPress={() => !isOwner && setSelectedModIds(p => p.includes(mId) ? p.filter(id => id !== mId) : [...p, mId])}
                  disabled={isOwner || !isUserOwner}
                  activeOpacity={0.8}
                >
                  <View style={styles.memberInfo}>
                    <Image source={{ uri: item.profilePicture || 'https://placehold.co/100x100/EEE/31343C/png?text=?' }} style={styles.memberAvatar} />
                    <View>
                      <Text style={[styles.memberName, { color: colors.textPrimary }, isSelected && !isOwner && styles.textWhite]}>{getUserDisplayName(item)}</Text>
                      <Text style={[styles.memberRole, { color: colors.textFaint }, isSelected && !isOwner && styles.textWhite70]}>{isOwner ? 'Owner' : isSelected ? 'Moderator' : 'Member'}</Text>
                    </View>
                  </View>

                  {isOwner ? (
                    <View style={[styles.ownerBadgeShield, { backgroundColor: chipIndigo }]}>
                      <Feather name="shield" size={16} color={colors.brand} />
                    </View>
                  ) : (
                    <View style={[styles.checkbox, { borderColor: colors.border }, isSelected && styles.checkboxActive]}>
                      {isSelected && <Feather name="check" size={14} color="white" />}
                    </View>
                  )}
                </PressableOpacity>
              );
            }}
          />
        </View>
      </Modal>

      {/* Remove Members Modal */}
      <Modal
        visible={isEditingMembers}
        transparent={false}
        animationType="slide"
        onRequestClose={() => setIsEditingMembers(false)}
      >
        <View style={[styles.fullModalContainer, { backgroundColor: colors.background, paddingTop: windowInsets.top }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <PressableOpacity onPress={() => setIsEditingMembers(false)} style={styles.headerIconButton}>
              <Feather name="chevron-down" size={28} color={colors.textSecondary} />
            </PressableOpacity>
            <Text style={[styles.modalTitleLarge, { color: colors.textPrimary }]}>Remove Members</Text>
            <View style={{ width: 44 }} />
          </View>
          <FlatList
            data={group?.members}
            keyExtractor={(item) => item._id}
            contentContainerStyle={{ padding: 20 }}
            renderItem={({ item }) => {
              const mId = item._id.toString();
              const isMbrOwner = mId === ((group?.owner as any)?._id || group?.owner || "").toString();
              const isMbrMod = group?.moderators?.some((m: any) => (m?._id || m).toString() === mId);
              const canRemove = (isUserOwner && !isMbrOwner) || (isUserMod && !isMbrOwner && !isMbrMod);

              return (
                <View style={[styles.selectMemberRow, { backgroundColor: colors.backgroundAlt }]}>
                  <View style={styles.memberInfo}>
                    <Image source={{ uri: item.profilePicture || 'https://placehold.co/100x100/EEE/31343C/png?text=?' }} style={styles.memberAvatar} />
                    <View>
                      <Text style={[styles.memberName, { color: colors.textPrimary }]}>{getUserDisplayName(item)}</Text>
                      <Text style={[styles.memberRole, { color: colors.textFaint }]}>{isMbrOwner ? 'Owner' : isMbrMod ? 'Moderator' : 'Member'}</Text>
                    </View>
                  </View>

                  {canRemove ? (
                    <PressableOpacity onPress={() => requireOnline('remove a member') && Alert.alert("Remove Member", `Remove ${item.firstName} from the group?`, [{ text: "Cancel", style: "cancel" }, { text: "Remove", style: "destructive", onPress: () => performMemberRemoval(mId) }])} disabled={isRemovingMemberId === mId}>
                        {isRemovingMemberId === mId ? <ActivityIndicator size="small" color={colors.danger} /> : <Feather name="x-circle" size={24} color={colors.danger} />}
                    </PressableOpacity>
                  ) : isMbrOwner ? <View style={[styles.ownerBadgeShield, { backgroundColor: chipIndigo }]}><Feather name="shield" size={16} color={colors.brand} /></View> : null}
                </View>
              );
            }}
          />
        </View>
      </Modal>

      {/* Transfer Ownership Modal */}
      <Modal
        visible={isTransferModalVisible}
        transparent={false}
        animationType="slide"
        onRequestClose={() => setIsTransferModalVisible(false)}
      >
        <View style={[styles.fullModalContainer, { backgroundColor: colors.background, paddingTop: windowInsets.top }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <PressableOpacity onPress={() => setIsTransferModalVisible(false)} style={styles.headerIconButton}>
              <Feather name="chevron-down" size={28} color={colors.textSecondary} />
            </PressableOpacity>
            <Text style={[styles.modalTitleLarge, { color: colors.textPrimary }]}>Transfer Ownership</Text>
            <View style={{ width: 44 }} />
          </View>
          <FlatList
            data={(group?.members || []).filter((m: any) => m._id.toString() !== ((group?.owner as any)?._id || group?.owner || "").toString())}
            keyExtractor={(item) => item._id}
            contentContainerStyle={{ padding: 20 }}
            ListHeaderComponent={() => (
              <Text style={[styles.modalSubtitleLeft, { color: colors.textMuted }]}>
                Pick a member to become the new owner. You'll become a moderator of this group.
              </Text>
            )}
            ListEmptyComponent={() => (
              <Text style={[styles.modalSubtitleLeft, { color: colors.textMuted }]}>No other members to transfer ownership to.</Text>
            )}
            renderItem={({ item }) => {
              const mId = item._id.toString();
              const isMbrMod = group?.moderators?.some((m: any) => (m?._id || m).toString() === mId);

              return (
                <PressableOpacity
                  style={[styles.selectMemberRow, { backgroundColor: colors.backgroundAlt }]}
                  onPress={() => handleTransferPress(item)}
                  disabled={!!isTransferringId}
                  activeOpacity={0.8}
                >
                  <View style={styles.memberInfo}>
                    <Image source={{ uri: item.profilePicture || 'https://placehold.co/100x100/EEE/31343C/png?text=?' }} style={styles.memberAvatar} />
                    <View>
                      <Text style={[styles.memberName, { color: colors.textPrimary }]}>{getUserDisplayName(item)}</Text>
                      <Text style={[styles.memberRole, { color: colors.textFaint }]}>{isMbrMod ? 'Moderator' : 'Member'}</Text>
                    </View>
                  </View>

                  {isTransferringId === mId ? (
                    <ActivityIndicator size="small" color="#8B5CF6" />
                  ) : (
                    <Feather name="chevron-right" size={20} color={colors.textFaint} />
                  )}
                </PressableOpacity>
              );
            }}
          />
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  closeButton: { padding: 8 },
  headerTitle: { fontSize: 18, fontWeight: '900', color: '#111827' },
  scroll: { flex: 1 },
  optionsContainer: { padding: 16 },
  sectionLabel: { fontSize: 13, fontWeight: '800', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10, marginLeft: 4 },
  optionButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: 'white', borderRadius: 16, marginBottom: 12, borderWidth: 1, borderColor: '#F3F4F6', elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2 },
  optionLeft: { flexDirection: 'row', alignItems: 'center', flex: 1, marginRight: 8 },
  iconContainer: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 16 },
  optionLabel: { fontSize: 16, fontWeight: '700', color: '#374151' },
  optionSubLabel: { fontSize: 12, color: '#9CA3AF', fontWeight: '500', marginTop: 2 },
  destructiveLabel: { color: '#EF4444' },
  footer: { padding: 32, alignItems: 'center' },
  footerText: { fontSize: 12, color: '#9CA3AF', textAlign: 'center', fontWeight: '500', lineHeight: 18 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  modalContent: { width: '100%', backgroundColor: 'white', borderRadius: 24, padding: 24, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 10, elevation: 5 },
  modalTitle: { fontSize: 20, fontWeight: '800', color: '#111827', marginBottom: 4, textAlign: 'center' },
  modalSubtitle: { fontSize: 14, color: '#6B7280', marginBottom: 16, textAlign: 'center', fontWeight: '500' },
  modalInput: { backgroundColor: '#F3F4F6', borderRadius: 12, padding: 16, fontSize: 16, color: '#111827', borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 20 },
  modalButtons: { flexDirection: 'row', gap: 12 },
  modalBtn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  modalBtnCancel: { backgroundColor: '#F3F4F6' },
  modalBtnSave: { backgroundColor: '#4FD1C5' },
  modalBtnDisabled: { backgroundColor: '#A7E4DE' },
  modalBtnTextCancel: { fontSize: 16, fontWeight: '700', color: '#4B5563' },
  modalBtnTextSave: { fontSize: 16, fontWeight: '700', color: 'white' },
  nameCelebrationStage: { width: '100%', height: 220, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' },
  nameCelebrationHeart: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  nameCelebrationHeartText: { fontSize: 56 },
  nameCelebrationNameRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', paddingHorizontal: 16 },
  nameCelebrationLetter: { fontSize: 30, fontWeight: '800', color: '#111827' },
  fullModalContainer: { flex: 1, backgroundColor: 'white' },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  modalTitleLarge: { fontSize: 20, fontWeight: '900', color: '#111827' },
  modalSubtitleLeft: { fontSize: 14, color: '#6B7280', marginHorizontal: 20, marginTop: 20, marginBottom: 10, fontWeight: '500', lineHeight: 20 },
  memberInfo: { flexDirection: 'row', alignItems: 'center' },
  memberAvatar: { width: 44, height: 44, borderRadius: 22, marginRight: 12 },
  memberName: { fontSize: 16, fontWeight: '700', color: '#1F2937' },
  memberRole: { fontSize: 12, color: '#9CA3AF', fontWeight: '600', marginTop: 1 },
  ownerBadgeShield: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#EEF2FF', alignItems: 'center', justifyContent: 'center' },
  saveBtnText: { color: '#4A90E2', fontWeight: '900', fontSize: 16 },
  headerIconButton: { padding: 4 },
  selectMemberRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, borderRadius: 18, marginHorizontal: 20, marginBottom: 10, backgroundColor: '#F9FAFB' },
  selectMemberRowActive: { backgroundColor: '#4A90E2' },
  textWhite: { color: 'white' },
  textWhite70: { color: 'rgba(255,255,255,0.7)' },
  checkbox: { width: 22, height: 22, borderRadius: 7, borderWidth: 2, borderColor: '#E5E7EB', alignItems: 'center', justifyContent: 'center' },
  checkboxActive: { backgroundColor: 'rgba(255,255,255,0.2)', borderColor: 'white' },
  imageModalContent: { width: 300, height: 300, alignItems: 'center', justifyContent: 'center' },
  imageModalAvatarWrap: { position: 'relative', marginTop: 8 },
  imageModalCameraBadge: { position: 'absolute', bottom: 2, right: 2, backgroundColor: '#4A90E2', borderRadius: 16, padding: 6, borderWidth: 2, borderColor: '#fff' },
  confirmBtn: { marginTop: 28, alignSelf: 'stretch', backgroundColor: '#4A90E2', borderRadius: 14, paddingVertical: 16, alignItems: 'center', justifyContent: 'center' },
  confirmBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  imageModalCancelBtn: { backgroundColor: '#F3F4F6' },
});

export default GroupSettings;
