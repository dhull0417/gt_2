import { View, Text, TextInput, Alert, KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';
import { PressableOpacity } from '@/components/ui/PressableOpacity';
import React, { useEffect, useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useUser } from '@clerk/expo';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useApiClient, userApi } from '@/utils/api';
import { useThemeColors } from '@/contexts/AppearanceContext';
import { toast } from '@/contexts/ToastContext';

const RESEND_COOLDOWN_SECONDS = 30;

const VerifyNewEmailScreen = () => {
    const { user } = useUser();
    const router = useRouter();
    const api = useApiClient();
    const colors = useThemeColors();
    const { emailId } = useLocalSearchParams<{ emailId: string }>();
    const pendingEmail = user?.emailAddresses.find(e => e.id === emailId)?.emailAddress;

    const [code, setCode] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [resendLoading, setResendLoading] = useState(false);
    const [resendCooldown, setResendCooldown] = useState(RESEND_COOLDOWN_SECONDS);

    useEffect(() => {
        if (resendCooldown <= 0) return;
        const timer = setInterval(() => setResendCooldown(s => s - 1), 1000);
        return () => clearInterval(timer);
    }, [resendCooldown]);

    const onResendPress = async () => {
        if (!user || !emailId) return;
        const emailAddressToVerify = user.emailAddresses.find(e => e.id === emailId);
        if (!emailAddressToVerify) return;

        setResendLoading(true);
        try {
            await emailAddressToVerify.prepareVerification({ strategy: 'email_code' });
            setResendCooldown(RESEND_COOLDOWN_SECONDS);
        } catch (err: any) {
            Alert.alert('Error', err.errors?.[0]?.longMessage || 'Could not resend the code. Please try again.');
        } finally {
            setResendLoading(false);
        }
    };

    const onVerifyPress = async () => {
        if (!user || !emailId) return;
        setIsLoading(true);
        try {
            const emailAddressToVerify = user.emailAddresses.find(e => e.id === emailId);
            if (!emailAddressToVerify) {
                throw new Error("Could not find the email address to verify.");
            }

            await emailAddressToVerify.attemptVerification({ code });

            // Update Mongo before Clerk's primary email so the two stores can't disagree
            try {
                await userApi.updateProfile(api, { email: emailAddressToVerify.emailAddress });
            } catch (mongoErr: any) {
                Alert.alert('Error', mongoErr.response?.data?.error || 'Could not update your email. Please try again.');
                return;
            }

            await user.update({ primaryEmailAddressId: emailAddressToVerify.id });

            toast.success("Your email address has been updated.");

            router.back();
            router.back(); // twice, back to main menu

        } catch (err: any) {
            Alert.alert('Error', err.errors?.[0]?.longMessage || 'An error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <SafeAreaView className="flex-1 bg-gray-100 dark:bg-black">
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}
                className="flex-1"
            >
                <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }} className="p-6">
                    <Text style={[styles.title, { color: colors.textPrimary }]}>Check your new email</Text>
                    <Text style={[styles.subtitle, { color: colors.textMuted }]}>
                        We've sent a verification code to{pendingEmail ? ':' : ' your new email address.'}
                    </Text>
                    {pendingEmail && (
                        <Text style={[styles.pendingEmail, { color: colors.textSecondary }]}>{pendingEmail}</Text>
                    )}
                    <TextInput
                        value={code}
                        onChangeText={setCode}
                        placeholder="Verification Code"
                        placeholderTextColor={colors.placeholder}
                        keyboardType="numeric"
                        style={[styles.input, { backgroundColor: colors.backgroundAlt, borderColor: colors.border, color: colors.textSecondary }]}
                    />
                    <PressableOpacity
                        onPress={onVerifyPress}
                        disabled={isLoading}
                        style={[styles.saveBtn, { backgroundColor: colors.brand }]}
                        activeOpacity={0.85}
                    >
                        {isLoading
                            ? <ActivityIndicator color="white" />
                            : <Text style={styles.saveBtnText}>Verify and Save</Text>}
                    </PressableOpacity>
                    <PressableOpacity
                        onPress={onResendPress}
                        disabled={resendLoading || resendCooldown > 0}
                        style={styles.resendBtn}
                        activeOpacity={0.7}
                    >
                        {resendLoading
                            ? <ActivityIndicator color={colors.brand} />
                            : (
                                <Text style={[styles.resendText, { color: resendCooldown > 0 ? colors.textFaint : colors.brand }]}>
                                    {resendCooldown > 0 ? `Resend code in ${resendCooldown}s` : 'Resend Code'}
                                </Text>
                            )}
                    </PressableOpacity>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    title: { fontSize: 22, fontWeight: '900', color: '#111827', letterSpacing: -0.5, textAlign: 'center' },
    subtitle: { fontSize: 15, color: '#6B7280', textAlign: 'center', marginTop: 8, marginBottom: 4, lineHeight: 21 },
    pendingEmail: { fontSize: 16, fontWeight: '800', color: '#1F2937', textAlign: 'center', marginBottom: 28 },
    input: { width: '100%', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 14, paddingHorizontal: 16, height: 56, fontSize: 18, color: '#1F2937', textAlign: 'center', letterSpacing: 4 },
    saveBtn: { width: '100%', height: 54, borderRadius: 16, backgroundColor: '#4A90E2', alignItems: 'center', justifyContent: 'center', marginTop: 28 },
    saveBtnText: { color: 'white', fontSize: 16, fontWeight: '800' },
    resendBtn: { height: 44, alignItems: 'center', justifyContent: 'center', marginTop: 8 },
    resendText: { color: '#4A90E2', fontSize: 14, fontWeight: '700' },
    resendTextDisabled: { color: '#9CA3AF' },
});

export default VerifyNewEmailScreen;
