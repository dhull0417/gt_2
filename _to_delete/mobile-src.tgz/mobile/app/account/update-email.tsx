import { View, Text, TextInput, Alert, KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';
import { PressableOpacity } from '@/components/ui/PressableOpacity';
import React, { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useUser } from '@clerk/expo';
import { useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useThemeColors } from '@/contexts/AppearanceContext';

const UpdateEmailScreen = () => {
    const { user } = useUser();
    const router = useRouter();
    const colors = useThemeColors();
    const [newEmail, setNewEmail] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const onUpdateEmailPress = async () => {
        if (!user) return;
        setIsLoading(true);
        try {
            // Clear stale unverified emails first, or Clerk rejects re-adding as "taken"
            const stale = user.emailAddresses.filter(
                (e) => e.id !== user.primaryEmailAddressId && e.verification?.status !== 'verified'
            );
            await Promise.all(stale.map((e) => e.destroy()));

            const newEmailAddress = await user.createEmailAddress({ email: newEmail });
            await newEmailAddress.prepareVerification({ strategy: 'email_code' });

            router.push({
                pathname: '/account/verify-email',
                params: { emailId: newEmailAddress.id }
            });
        } catch (err: any) {
            Alert.alert('Error', err.errors?.[0]?.longMessage || 'An error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <SafeAreaView className="flex-1 bg-gray-100 dark:bg-black">
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}
                className="flex-1"
            >
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="p-6">
                    <View style={{ marginBottom: 20 }}>
                        <Text style={[styles.label, { color: colors.textFaint }]}>Current Email</Text>
                        <View style={[styles.readOnlyBox, { backgroundColor: colors.backgroundAlt, borderColor: colors.border }]}>
                            <Feather name="mail" size={16} color={colors.textFaint} />
                            <Text style={[styles.readOnlyText, { color: colors.textMuted }]}>{user?.primaryEmailAddress?.emailAddress}</Text>
                        </View>
                    </View>
                    <View style={{ marginBottom: 28 }}>
                        <Text style={[styles.label, { color: colors.textFaint }]}>New Email Address</Text>
                        <TextInput
                            value={newEmail}
                            onChangeText={setNewEmail}
                            placeholder="Enter your new email"
                            placeholderTextColor={colors.placeholder}
                            keyboardType="email-address"
                            autoCapitalize="none"
                            style={[styles.input, { backgroundColor: colors.backgroundAlt, borderColor: colors.border, color: colors.textSecondary }]}
                        />
                    </View>
                    <PressableOpacity
                        onPress={onUpdateEmailPress}
                        disabled={isLoading}
                        style={[styles.saveBtn, { backgroundColor: colors.brand }]}
                        activeOpacity={0.85}
                    >
                        {isLoading
                            ? <ActivityIndicator color="white" />
                            : <Text style={styles.saveBtnText}>Continue</Text>}
                    </PressableOpacity>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    label: { fontSize: 12, fontWeight: '800', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 },
    input: { width: '100%', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 14, paddingHorizontal: 16, height: 56, fontSize: 16, color: '#1F2937' },
    readOnlyBox: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 14, paddingHorizontal: 16, height: 56 },
    readOnlyText: { fontSize: 15, fontWeight: '600', color: '#6B7280' },
    saveBtn: { width: '100%', height: 54, borderRadius: 16, backgroundColor: '#4A90E2', alignItems: 'center', justifyContent: 'center' },
    saveBtnText: { color: 'white', fontSize: 16, fontWeight: '800' },
});

export default UpdateEmailScreen;
