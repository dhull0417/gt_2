import { View, Text, Alert, ActivityIndicator, StyleSheet } from 'react-native';
import { requireOnline } from '@/utils/offlineState';
import { PressableOpacity } from '@/components/ui/PressableOpacity';
import React, { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@clerk/expo';
import { useQueryClient } from '@tanstack/react-query';
import { Feather } from '@expo/vector-icons';
import { useApiClient, userApi } from '@/utils/api';
import { usePremium } from '@/hooks/usePremium';
import { useAppearance, useThemeColors } from '@/contexts/AppearanceContext';
import { unregisterPushToken } from '@/hooks/usePushNotifications';
import { haptic } from '@/utils/haptics';

const DeleteAccountScreen = () => {
    const { signOut } = useAuth();
    const api = useApiClient();
    const { isPremium } = usePremium();
    const queryClient = useQueryClient();
    const colors = useThemeColors();
    const { scheme } = useAppearance();
    const isDark = scheme === 'dark';
    const [deleteLoading, setDeleteLoading] = useState(false);

    const handleDeleteAccount = () => {
        if (!requireOnline('delete your account')) return;
        Alert.alert(
            'Final Confirmation',
            'This will permanently delete your account from GroupThat. There is no way to recover it.' +
                (isPremium
                    ? '\n\nYour Premium subscription is not cancelled by deleting your account. Cancel it in your App Store or Google Play subscription settings to avoid further charges.'
                    : ''),
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Yes, Delete My Account',
                    style: 'destructive',
                    onPress: async () => {
                        setDeleteLoading(true);
                        try {
                            await unregisterPushToken(api);
                            await userApi.deleteAccount(api);
                            haptic.success();
                            queryClient.clear();
                            await signOut();
                        } catch {
                            Alert.alert('Error', 'Something went wrong while deleting your account. Please try again.');
                        } finally {
                            setDeleteLoading(false);
                        }
                    },
                },
            ]
        );
    };

    return (
        <SafeAreaView className="flex-1 bg-gray-100 dark:bg-black">
            <View className="p-6">
                <View style={[
                    styles.warningBox,
                    { backgroundColor: isDark ? '#3B1E1E' : '#FEF2F2', borderColor: isDark ? '#5C2E2E' : '#FCA5A5' },
                ]}>
                    <Feather name="alert-triangle" size={22} color={colors.danger} style={{ marginBottom: 10 }} />
                    <Text style={[styles.warningTitle, { color: colors.danger }]}>Delete Account</Text>
                    <Text style={[styles.warningText, { color: isDark ? '#FCA5A5' : '#7F1D1D' }]}>
                        Are you sure you want to permanently delete your account? This cannot be undone.
                        {'\n\n'}
                        All your data, messages, and any groups you own will be deleted or transferred.
                        {isPremium
                            ? '\n\nPremium features are tied to the group owner\'s subscription. If a group you own is transferred to someone else, its Premium features will be paused unless the new owner has their own Premium subscription.'
                            : ''}
                    </Text>
                </View>

                <PressableOpacity
                    onPress={handleDeleteAccount}
                    disabled={deleteLoading}
                    style={[
                        styles.deleteBtn,
                        { borderColor: colors.danger, backgroundColor: isDark ? '#3B1E1E' : '#FEF2F2' },
                    ]}
                    activeOpacity={0.7}
                >
                    {deleteLoading
                        ? <ActivityIndicator size="small" color={colors.danger} />
                        : <Text style={[styles.deleteText, { color: colors.danger }]}>Delete Account</Text>}
                </PressableOpacity>
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    warningBox: {
        backgroundColor: '#FEF2F2',
        borderWidth: 1,
        borderColor: '#FCA5A5',
        borderRadius: 16,
        padding: 18,
        marginBottom: 20,
    },
    warningTitle: {
        fontSize: 16,
        fontWeight: '800',
        color: '#B91C1C',
        marginBottom: 6,
    },
    warningText: {
        fontSize: 14,
        color: '#7F1D1D',
        lineHeight: 20,
    },
    deleteBtn: {
        height: 50,
        borderRadius: 14,
        borderWidth: 2,
        borderColor: '#EF4444',
        backgroundColor: '#FEF2F2',
        alignItems: 'center',
        justifyContent: 'center',
    },
    deleteText: {
        color: '#EF4444',
        fontWeight: '900',
        textTransform: 'uppercase',
        fontSize: 12,
    },
});

export default DeleteAccountScreen;
