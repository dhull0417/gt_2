import React, { useState, useEffect, useRef } from 'react';
import { requireOnline } from '@/utils/offlineState';
import { getErrorMessage } from '@/utils/networkError';
import { meetupStartInstant, meetupEndInstant, formatMeetupDate, formatMeetupTimeRange, viewerZone } from '@/utils/meetupTime';
import { LinkifiedText } from '@/components/LinkifiedText';
import { haptic } from '@/utils/haptics';
import { CancelReasonSheet } from '@/components/CancelReasonSheet';
import {
    View,
    Text,
    ScrollView,
    Image,
    Alert,
    ActivityIndicator,
    Modal,
    StyleSheet,
    Platform,
    Pressable,
} from 'react-native';
import { PressableOpacity } from '@/components/ui/PressableOpacity';
import { FREQUENCY_LABELS, buildFrequencyDetail } from '@/utils/meetupFrequency';
import { Feather, MaterialIcons, Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import VideoServiceIcon from './VideoServiceIcon';
import { detectVideoService } from '../utils/videoLinks';
import { openLocation } from '../utils/openLink';
import { getUserDisplayName, getUserInitial } from '../utils/groupDisplay';
import Animated, {
    FadeIn,
    FadeOut,
    LinearTransition,
    useSharedValue,
    useAnimatedStyle,
    withTiming,
    withSpring,
    Easing,
} from 'react-native-reanimated';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@clerk/expo';
import { Meetup, User, useApiClient, userApi, meetupApi, groupApi } from '@/utils/api';
import { getMeetupStatus, isRsvpDeadlinePassed as isRsvpDeadlinePassedFn, isRsvpLockedFor, describeRsvpOpensFor, canPriorityBump, isMeetupFull } from '@/utils/meetupStatus';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useRsvp } from '@/hooks/useRsvp';
import { AssignmentsSheet } from '@/components/MeetupAssignments';
import { assignmentsActive, summarizeAssignments } from '@/utils/assignments';
import { ridersOf } from '@/utils/rides';
import { showTourneySetup } from '@/utils/meetupActions';
import { tournamentApi } from '@/utils/tournamentApi';
import MeetupConfirmSheet from '@/components/MeetupConfirmSheet';
import MeetupTournamentCard from '@/components/MeetupTournamentCard';
import { shouldPromptAfterIn, tileTapAction } from '@/utils/confirmTabs';
import { broadcastMeetupUpdate } from '@/utils/groupRealtime';
import RsvpResponseOverlay from '@/components/RsvpResponseOverlay';
import { useGetMeetups } from '@/hooks/useGetMeetups';
import { RsvpBreather } from '@/components/RsvpBreather';
import { useRouter } from 'expo-router';
import * as Calendar from 'expo-calendar';
import { ActionSheet } from './ActionSheet';
import { MeetupForm } from './meetup-form/MeetupForm';
import { draftFromMeetup, updatePayload, validateDraft, type MeetupDraft } from '@/utils/meetupFormDraft';
import { toast, ToastPortal } from '@/contexts/ToastContext';
import { formatAgo } from '@/utils/listTime';
import { useAppearance, useThemeColors } from '@/contexts/AppearanceContext';
import { PulsingWatermark } from '@/components/meetup-detail/PulsingWatermark';
import { InOutSwapIcon } from '@/components/meetup-detail/InOutSwapIcon';
import { styles, dmStyles } from '@/components/meetup-detail/styles';
import { buildInviteMessage } from '@/utils/inviteMessage';
import { shareInvite, prefetchShareImage } from '@/utils/shareInvite';
import { muteStateFor, restoreRequest } from '@/utils/groupMute';

interface MeetupDetailModalProps {
  meetup: Meetup | null;
  onClose: () => void;
  /** Called when the sheet opens another screen (chat, DM, Teams & Tourneys). A container that
   *  hosts this sheet inside its own Modal (e.g. Upcoming meetups) closes itself here, or the
   *  new screen opens hidden underneath it. */
  onNavigate?: () => void;
}

// Extracts user ID whether the array holds strings or populated objects
const getUserId = (u: User | string): string => typeof u === 'string' ? u : u._id;

const MeetupDetailModal = ({ meetup: initialMeetup, onClose, onNavigate }: MeetupDetailModalProps) => {
    const api = useApiClient();
    const router = useRouter();
    const queryClient = useQueryClient();
    const { getToken } = useAuth();
    const colors = useThemeColors();
    const insets = useSafeAreaInsets();
    const { scheme } = useAppearance();
    const isDark = scheme === 'dark';

    const [meetup, setMeetup] = useState<Meetup | null>(initialMeetup);
    const { data: allMeetups } = useGetMeetups();
    const [swapIconNonce, setSwapIconNonce] = useState(0);

    // Edit Meetup: the form's draft while it's open (null = closed), and what it started from.
    const [editDraft, setEditDraft] = useState<MeetupDraft | null>(null);
    const editOriginal = useRef<MeetupDraft | null>(null);
    const [isUpdating, setIsUpdating] = useState(false);
    const [cancelSheetVisible, setCancelSheetVisible] = useState(false);
    const [isCancelling, setIsCancelling] = useState(false);
    const [dmTargetUser, setDmTargetUser] = useState<User | null>(null);
    // Member an owner/moderator is editing assignments for.
    const [assignTarget, setAssignTarget] = useState<User | null>(null);
    // Your own Bring / Rides / Questions sheet (pops after tapping In; also opened from your tile).
    const [selfConfirmOpen, setSelfConfirmOpen] = useState(false);
    // Member whose Bring / Rides / Questions picks are being looked at (tapped their tile).
    const [reviewUser, setReviewUser] = useState<User | null>(null);
    // Driver whose riders are shown in the "Riding with…" sheet.
    const [ridersDriverId, setRidersDriverId] = useState<string | null>(null);
    const [isCreatingDM, setIsCreatingDM] = useState(false);
    const [isSendingReminder, setIsSendingReminder] = useState(false);
    const [isUpdatingTargetRsvp, setIsUpdatingTargetRsvp] = useState(false);


    useEffect(() => {
        setMeetup(initialMeetup);
        setDescriptionExpanded(false);
        descriptionChevronRotation.value = 0;
        setLocationExpanded(false);
        locationChevronRotation.value = 0;
    }, [initialMeetup]);

    useEffect(() => {
        if (allMeetups && meetup) {
            const updated = allMeetups.find(e => e._id === meetup._id);
            if (updated) setMeetup(updated);
        }
    }, [allMeetups]);

    const { data: currentUser } = useQuery<User, Error>({
        queryKey: ['currentUser'],
        queryFn: () => userApi.getCurrentUser(api),
    });

    const { mutate: rsvp, isBusyFor: isRsvpBusyFor, isQueuedFor: isRsvpQueuedFor } = useRsvp();
    const isRsvping = meetup ? isRsvpBusyFor(meetup._id) : false;
    const rsvpQueued = meetup ? isRsvpQueuedFor(meetup._id) : false;

    // Same query as MeetupTournamentCard: decides whether ⋯ offers "Set up Teams & Tourneys".
    const { data: tournament } = useQuery({
        queryKey: ['tournamentForMeetup', meetup?._id],
        queryFn: () => tournamentApi.getForMeetup(api, meetup!._id),
        enabled: !!meetup,
        staleTime: 15000,
    });
    const [localGuestCount, setLocalGuestCount] = useState(0);
    const [isSettingGuests, setIsSettingGuests] = useState(false);
    const [guestExpanded, setGuestExpanded] = useState(false);
    const [descriptionExpanded, setDescriptionExpanded] = useState(false);
    const descriptionChevronRotation = useSharedValue(0);
    const descriptionChevronStyle = useAnimatedStyle(() => ({
        transform: [{ rotate: `${descriptionChevronRotation.value}deg` }],
    }));
    const descriptionPressScale = useSharedValue(1);
    const descriptionPressStyle = useAnimatedStyle(() => ({
        transform: [{ scale: descriptionPressScale.value }],
    }));
    const [locationExpanded, setLocationExpanded] = useState(false);
    const [locationTruncated, setLocationTruncated] = useState(false);
    const locationChevronRotation = useSharedValue(0);
    const locationChevronStyle = useAnimatedStyle(() => ({
        transform: [{ rotate: `${locationChevronRotation.value}deg` }],
    }));
    const [manualRsvpEdit, setManualRsvpEdit] = useState(false);
    const [isActionsMenuVisible, setIsActionsMenuVisible] = useState(false);

    const openActionsMenu = () => setIsActionsMenuVisible(true);

    useEffect(() => {
        if (!isSettingGuests && meetup && currentUser) {
            const entry = meetup.guests?.find(g => g.userId === currentUser.clerkId);
            setLocalGuestCount(entry?.count ?? 0);
        }
    }, [meetup, currentUser, isSettingGuests]);

    // Fetch the group photo now so "Invite to Meetup" can show it in the share sheet right away.
    useEffect(() => { prefetchShareImage(meetup?.group?.image); }, [meetup?.group?.image]);

    const waitlistUsers = (meetup?.waitlist || [])
        .map(u => (meetup?.members || []).find(m => m._id === getUserId(u)))
        .filter((u): u is User => !!u);

    if (!meetup || !currentUser) return null;

    const meetupGroupId = typeof meetup.group === 'string' ? meetup.group : meetup.group._id;

    // --- READ-ONLY & PERMISSIONS LOGIC ---
    const isOwner = typeof meetup.group === 'object' ? meetup.group.owner === currentUser._id : false;
    const groupData = meetup.group as any;
    const isMod = typeof meetup.group === 'object' && Array.isArray(groupData.moderators)
        ? groupData.moderators.some((m: any) => typeof m === 'string' ? m === currentUser._id : m._id === currentUser._id)
        : false;

    const { isCancelled, isExpired, isHappeningNow } = getMeetupStatus(meetup);

    const isRsvpLocked = isRsvpLockedFor(meetup, currentUser?._id);

    const isRsvpDeadlinePassed = isRsvpDeadlinePassedFn(meetup);

    // Controls all "adjustment" UI
    const isReadOnly = isCancelled || isExpired;
    const canManage = (isOwner || isMod) && !isReadOnly;

    // Whoever created this one-off meetup can also edit/cancel it, even without owner/mod
    // status — but NOT override other members' RSVPs or send reminders (canManage handles those).
    const createdBy = (meetup as any).createdBy;
    const isCreator = !!createdBy && (typeof createdBy === 'string' ? createdBy === currentUser._id : createdBy._id === currentUser._id);
    const canEditOrCancel = (isOwner || isMod || isCreator) && !isReadOnly;
    // A cancelled (but not yet expired) meetup can still be restored by the same
    // set of people who could cancel it — unlike canEditOrCancel, this stays true
    // while isCancelled so the "Reactivate" action remains reachable.
    const canCancelOrRestore = (isOwner || isMod || isCreator) && !isExpired;

    // Owner can override any RSVP; a moderator can override only regular members.
    const canManageTarget = (target: User): boolean =>
        canManage && target._id !== currentUser._id && (
            isOwner || (
                groupData.owner !== target._id &&
                !(Array.isArray(groupData.moderators) && groupData.moderators.some((m: any) => (typeof m === 'string' ? m : m._id) === target._id))
            )
        );

    const isFull = isMeetupFull(meetup); // guests count toward the limit
    const isWaitlisted = meetup.waitlist?.some(u => getUserId(u) === currentUser._id) || false;
    const isIn = meetup.in?.some(u => getUserId(u) === currentUser._id) || false;
    const isOut = meetup.out?.some(u => getUserId(u) === currentUser._id) || false;
    const hasRsvpResponse = isIn || isOut || isWaitlisted;
    const showRsvpSelector = !hasRsvpResponse || manualRsvpEdit;
    // Waitlists are a Premium feature of the group owner: on a full meetup in a
    // non-Premium group there is nothing to join, so the button reads "Full".
    // (Only `=== false` counts, so a missing flag never blocks; the server enforces.)
    const waitlistLocked = isFull && !isIn && !isWaitlisted && (meetup.group?.waitlistEnabled ?? meetup.group?.isPremium) === false;
    const canBump = canPriorityBump(meetup, currentUser?._id);
    const inUnselected = !isIn && !isWaitlisted && !(isFull && !isIn);
    const outUnselected = !isOut;
    const isUndecided = inUnselected && outUnselected;
    // While undecided, fill both buttons like they're selected so neither reads as the "default" choice.
    const inFilled = !inUnselected || isUndecided;
    const outFilled = !outUnselected || isUndecided;

    // Tint matches RSVP button colors: amber until responded, green (in/waitlisted), red (out).
    // Dark mode swaps in muted, low-saturation versions of the same hues (mirrors MeetupCard).
    const modalBackgroundColor = isDark
        ? (isOut ? '#3A1F1F' : (isIn || isWaitlisted) ? '#16261D' : colors.surfaceAlt)
        : (isOut ? '#FEF2F2' : (isIn || isWaitlisted) ? '#EDF5F0' : '#FFFEFA');

    const goingUsers = (meetup.members || []).filter(m => meetup.in?.some(u => getUserId(u) === m._id));
    const outUsers = (meetup.members || []).filter(m => meetup.out?.some(u => getUserId(u) === m._id));

    // Guests stay tied to host's clerkId even after the host RSVPs 'out' (Keep Guests).
    // Host then drops from goingUsers, so surface guests as their own row.
    const orphanGuestEntries = (meetup.guests || []).filter(g => {
        if (!g.count) return false;
        return !goingUsers.some(user => (user as any).clerkId === g.userId);
    });
    // Every user with guests gets its own tile (not just orphans), in the In grid.
    const allGuestEntries = (meetup.guests || []).filter(g => !!g.count);
    const totalGuestsForInTab = goingUsers.reduce((sum, user) => {
        const entry = (meetup.guests || []).find(g => g.userId === (user as any).clerkId);
        return sum + (entry?.count ?? 0);
    }, 0) + orphanGuestEntries.reduce((sum, g) => sum + g.count, 0);

    const respondedIds = new Set([
        ...(meetup.in || []).map(getUserId),
        ...(meetup.out || []).map(getUserId),
        ...(meetup.waitlist || []).map(getUserId),
    ]);
    const undecidedUsers = (meetup.members || []).filter(m => !respondedIds.has(m._id));

    const performRsvp = (status: 'in' | 'out', opts?: { skipResponsePopup?: boolean }) => {
        rsvp({ meetupId: meetup._id, status, skipResponsePopup: opts?.skipResponsePopup }, {
            onSuccess: (data: any) => {
                queryClient.invalidateQueries({ queryKey: ['meetups'] });
                if (data.meetup) setMeetup(data.meetup);
                setManualRsvpEdit(false);
                // Newly "In": the Bring / Rides / Questions sheet, while any of them is unpicked.
                if (status === 'in' && data.meetup && shouldPromptAfterIn(data.meetup, currentUser._id)) {
                    setSelfConfirmOpen(true);
                }
            },
            // The reason ("deadline passed", "full") is shown once by the global RSVP error toast.
        });
    };

    const performSetGuests = async (count: number) => {
        setLocalGuestCount(count);
        setIsSettingGuests(true);
        try {
            const result = await meetupApi.setGuestCount(api, meetup._id, count);
            queryClient.invalidateQueries({ queryKey: ['meetups'] });
            broadcastMeetupUpdate(getToken, meetupGroupId);
            if (result.meetup) setMeetup(result.meetup);
        } catch (e: any) {
            const prev = meetup.guests?.find(g => g.userId === currentUser.clerkId)?.count ?? 0;
            setLocalGuestCount(prev);
            // 409: not enough open spots (guests never take a spot that isn't free), or the rider's
            // party is in a car and has to leave it before adding guests.
            if (e?.response?.status === 409 && e.response.data?.message) {
                Alert.alert(e.response.data.error === 'leave_ride_first' ? 'Leave your car first' : 'Not enough room', e.response.data.message);
            }
            else Alert.alert('Error', 'Could not update your guests. Please try again.');
        } finally {
            setIsSettingGuests(false);
        }
    };



    const handleRsvpAction = (status: 'in' | 'out', opts?: { skipResponsePopup?: boolean }) => {
        if (isReadOnly || isRsvpLocked || isRsvpDeadlinePassed) return;
        if (status === 'out' && localGuestCount > 0) {
            Alert.alert(
                'Remove Guests?',
                'Remove your guests from this Meetup too?',
                [
                    { text: 'Keep Guests', onPress: () => performRsvp('out', opts) },
                    {
                        text: 'Remove Guests',
                        style: 'destructive',
                        onPress: async () => {
                            await performSetGuests(0);
                            performRsvp('out', opts);
                        },
                    },
                ]
            );
            return;
        }
        performRsvp(status, opts);
    };

    const handleRsvpOutAndMute = () => {
        setGuestExpanded(false);
        handleRsvpAction('out', { skipResponsePopup: true });
        // Undo puts back whatever mute the member had before (it may have been a partial one).
        const previousMute = muteStateFor(currentUser, meetup.group._id);
        userApi.toggleGroupMute(api, meetup.group._id, 'untilNext')
            .then(() => {
                toast.show({
                    message: `Out. ${meetup.group.name} muted until the next meetup.`,
                    kind: 'success',
                    actionLabel: 'Undo',
                    onAction: () => {
                        const { muteType, kinds } = restoreRequest(previousMute);
                        userApi.toggleGroupMute(api, meetup.group._id, muteType, muteType === 'none' ? undefined : kinds)
                          .then(() => queryClient.invalidateQueries({ queryKey: ['currentUser'] })).catch(() => {});
                    },
                });
            })
            .catch(() => {});
    };

    const handleAddToCalendar = async () => {
        const { status } = await Calendar.requestCalendarPermissionsAsync();
        if (status !== 'granted') {
            Alert.alert('Permission Required', 'Please allow calendar access in your device settings to add meetup events.');
            return;
        }

        // The real start moment in the GROUP's timezone, whatever timezone this phone is in.
        const startDate = meetupStartInstant(meetup);
        // The meetup's end time when it has one, otherwise 1 hour.
        const endDate = meetupEndInstant(meetup);
        const groupName = (meetup.group as any)?.name || '';

        try {
            // Search all calendars (including subscribed feed) for a duplicate
            const allCalendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
            const searchStart = new Date(startDate.getTime() - 60 * 1000);
            const searchEnd = new Date(startDate.getTime() + 60 * 1000);
            const existing = await Calendar.getEventsAsync(
                allCalendars.map(c => c.id),
                searchStart,
                searchEnd
            );

            const alreadyExists = existing.some(e =>
                e.title === meetup.name ||                          // added via this button
                e.title === `${groupName}: ${meetup.name}` ||      // added via calendar feed sync
                (e.notes?.includes(`groupthat-id:${meetup._id}`))  // tagged from a previous add
            );

            if (alreadyExists) {
                Alert.alert('Already on Your Calendar', 'This meetup is already saved to your calendar.');
                return;
            }

            let calendarId: string;
            if (Platform.OS === 'ios') {
                const defaultCal = await Calendar.getDefaultCalendarAsync();
                calendarId = defaultCal.id;
            } else {
                const writable = allCalendars.find(c => c.isPrimary && c.allowsModifications)
                    || allCalendars.find(c => c.allowsModifications);
                if (!writable) {
                    Alert.alert('Error', 'No writable calendar found on your device.');
                    return;
                }
                calendarId = writable.id;
            }

            await Calendar.createEventAsync(calendarId, {
                title: meetup.name,
                startDate,
                endDate,
                location: meetup.location || (meetup.group as any)?.defaultLocation || '',
                notes: `GroupThat meetup with ${groupName}\ngroupthat-id:${meetup._id}`,
                timeZone: meetup.timezone,
            });
            toast.success(`"${meetup.name}" added to your calendar.`);
        } catch {
            Alert.alert('Error', 'Could not add this event to your calendar. Please try again.');
        }
    };

    const handleOpenLocation = (address: string) => openLocation(address);

    // Close this sheet (and any modal hosting it), then open the screen.
    const leaveTo = (href: any) => {
        onClose();
        onNavigate?.();
        router.push(href);
    };

    const handleGoToChat = () => {
        leaveTo({
            pathname: '/group-chat/[id]',
            params: { id: meetup.group._id }
        });
    };

    const handleInviteToMeetup = async () => {
        try {
            const { link, code } = await groupApi.generateInviteLink(api, meetup.group._id);
            await shareInvite({
                message: buildInviteMessage({ meetupName: meetup.name, link, code, meetupId: meetup._id, referrerId: currentUser?._id }),
                meetupName: meetup.name,
                groupName: meetup.group?.name,
                imageUrl: meetup.group?.image,
            });
        } catch {
            Alert.alert('Error', 'Could not create invite link. Please try again.');
        }
    };

    const handleSendDM = async () => {
        if (!dmTargetUser) return;
        setIsCreatingDM(true);
        try {
            const { group } = await groupApi.createOrGetDM(api, dmTargetUser._id);
            queryClient.invalidateQueries({ queryKey: ['groups'] });
            setDmTargetUser(null);
            leaveTo({
                pathname: '/group-chat/[id]',
                params: { id: group._id }
            });
        } catch {
            Alert.alert('Error', 'Could not open DM. Please try again.');
        } finally {
            setIsCreatingDM(false);
        }
    };

    const handleSendReminder = async (userId?: string) => {
        setIsSendingReminder(true);
        try {
            await meetupApi.sendReminder(api, meetup._id, userId);
            setDmTargetUser(null);
            if (!userId) setMeetup((m) => (m ? { ...m, lastRemindedAt: new Date().toISOString() } : m));
            haptic.success();
            toast.success(userId ? "Reminder sent. They'll get a push to RSVP." : 'Reminder sent to everyone who is still undecided.');
        } catch (e: any) {
            Alert.alert('Error', e.response?.data?.error || 'Could not send the reminder. Please try again.');
        } finally {
            setIsSendingReminder(false);
        }
    };

    const handleAdminRsvpChange = async (targetUserId: string, status: 'in' | 'out') => {
        setIsUpdatingTargetRsvp(true);
        try {
            const result = await meetupApi.handleRsvp(api, { meetupId: meetup._id, status, targetUserId });
            if (result.meetup) setMeetup(result.meetup);
            queryClient.invalidateQueries({ queryKey: ['meetups'] });
            broadcastMeetupUpdate(getToken, meetupGroupId);
            setDmTargetUser(null);
        } catch (e: any) {
            Alert.alert('Error', e.response?.data?.error || "Could not update their RSVP. Please try again.");
        } finally {
            setIsUpdatingTargetRsvp(false);
        }
    };

    const handleRemindAll = () => {
        Alert.alert(
            'Remind All Undecided?',
            `Send an RSVP reminder to all ${undecidedUsers.length} undecided member${undecidedUsers.length === 1 ? '' : 's'}?`,
            [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Send', onPress: () => handleSendReminder() },
            ]
        );
    };

    const openEditModal = () => {
        const d = draftFromMeetup(meetup);
        editOriginal.current = d;
        setEditDraft(d);
    };

    const handleUpdateMeetupDetails = async () => {
        if (isReadOnly || !editDraft || !editOriginal.current || validateDraft(editDraft)) return;
        // Only what changed: untouched settings aren't sent, so a series meetup only gets its
        // own settings when they're actually changed here.
        const changes = updatePayload(editOriginal.current, editDraft);
        if (Object.keys(changes).length === 0) {
            setEditDraft(null);
            return;
        }
        setIsUpdating(true);
        try {
            const response = await meetupApi.updateMeetup(api, { meetupId: meetup._id, ...changes } as any);
            await queryClient.invalidateQueries({ queryKey: ['meetups'] });
            if (response?.meetup) setMeetup(response.meetup);
            broadcastMeetupUpdate(getToken, meetupGroupId);
            setEditDraft(null);
            toast.success("Meetup details updated.");
        } catch (error: any) {
            const data = error?.response?.data;
            Alert.alert("Update Failed", data?.error === 'premium_required' && data?.message ? data.message : getErrorMessage(error, "Couldn't save the meetup. Please try again."));
        } finally {
            setIsUpdating(false);
        }
    };

    // RSVP questions have their own screen; leaving the form drops unsaved edits, so ask first.
    const openMeetupQuestions = () => {
        const go = () => {
            setEditDraft(null);
            leaveTo({ pathname: '/group-questions/[id]', params: { id: meetupGroupId, meetupId: meetup._id } });
        };
        const unsaved = editDraft && editOriginal.current && Object.keys(updatePayload(editOriginal.current, editDraft)).length > 0;
        if (!unsaved) return go();
        Alert.alert('Unsaved changes', 'Leave without saving your changes to this meetup?', [
            { text: 'Keep editing', style: 'cancel' },
            { text: 'Leave', style: 'destructive', onPress: go },
        ]);
    };

    // Items someone is bringing and their ride role, shown as pills under their name.
    const assignmentSummary = assignmentsActive(meetup) ? summarizeAssignments(meetup) : null;
    const renderAssignmentPills = (userId: string) => {
        if (!assignmentSummary) return null;
        const pills: { key: string; label: string; icon: keyof typeof Feather.glyphMap; bg: string; fg: string; onPress?: () => void }[] = [];
        for (const item of assignmentSummary.items) {
            if (item.claimedBy.includes(userId)) {
                pills.push({ key: `i-${item._id}`, label: item.name, icon: 'shopping-bag', bg: '#F0FDFA', fg: '#0F766E' });
            }
        }
        const driver = assignmentSummary.drivers.find(d => d.userId === userId);
        if (driver) {
            pills.push({ key: 'driver', label: `Driver · ${driver.seats}`, icon: 'truck', bg: '#EEF6FF', fg: '#2563EB', onPress: () => setRidersDriverId(userId) });
        } else if (assignmentSummary.passengers.includes(userId)) {
            pills.push({ key: 'passenger', label: 'Needs ride', icon: 'user', bg: '#FFF7ED', fg: '#C2410C' });
        }
        if (pills.length === 0) return null;
        return (
            <View style={styles.pillStack}>
                {pills.map(p => {
                    const content = (
                        <>
                            <Feather name={p.icon} size={9} color={p.fg} />
                            <Text style={[styles.assignPillText, { color: p.fg }]} numberOfLines={1}>{p.label}</Text>
                        </>
                    );
                    // The driver pill shows who's riding; its own press stops the tile's press.
                    return p.onPress ? (
                        <PressableOpacity
                            key={p.key}
                            onPress={() => { haptic.select(); p.onPress!(); }}
                            accessibilityLabel="See who's riding"
                            hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                            style={[styles.assignPill, { backgroundColor: p.bg }]}
                        >
                            {content}
                        </PressableOpacity>
                    ) : (
                        <View key={p.key} style={[styles.assignPill, { backgroundColor: p.bg }]}>{content}</View>
                    );
                })}
            </View>
        );
    };

    const renderUserTile = (user: User, key: string, opts?: { waitlistPosition?: number }) => {
        // Tiles open Bring / Rides / Questions picks (yours to edit, anyone else's to look at);
        // without picks, someone else's tile opens the person sheet.
        const action = tileTapAction(meetup, currentUser._id, user._id, isReadOnly);
        const Wrapper = action === 'none' ? View : PressableOpacity;
        const wrapperProps = action === 'edit'
            ? { onPress: () => setSelfConfirmOpen(true), activeOpacity: 0.7, accessibilityLabel: 'Edit my picks' }
            : action === 'review'
                ? { onPress: () => setReviewUser(user), activeOpacity: 0.7, accessibilityLabel: `See ${getUserDisplayName(user)}'s picks` }
                : action === 'person'
                    ? { onPress: () => setDmTargetUser(user), activeOpacity: 0.7 }
                    : {};
        return (
            <Wrapper key={key} style={styles.gridItem} {...wrapperProps}>
                <View style={styles.gridAvatarWrap}>
                    {user.profilePicture
                        ? <Image source={{ uri: user.profilePicture }} style={[styles.gridAvatar, { backgroundColor: colors.backgroundAlt }]} />
                        : (
                            <View style={[styles.gridAvatar, styles.gridAvatarPlaceholder, { backgroundColor: colors.backgroundAlt }]}>
                                <Feather name="user" size={22} color={colors.textFaint} />
                            </View>
                        )}
                    {opts?.waitlistPosition != null && (
                        <View style={[styles.waitlistBadge, { borderColor: colors.surface }]}>
                            <Text style={styles.waitlistBadgeText}>{opts.waitlistPosition}</Text>
                        </View>
                    )}
                </View>
                <Text style={[styles.gridName, { color: colors.textSecondary }]} numberOfLines={1}>{getUserDisplayName(user)}</Text>
                {renderAssignmentPills(user._id)}
            </Wrapper>
        );
    };

    // Owners/moderators (and the host themself) can take guests off a meetup.
    const canRemoveGuestsOf = (host: User | undefined) =>
        !!host && !isReadOnly && (host._id === currentUser._id || canManageTarget(host));

    const removeGuests = async (hostClerkId: string, count: number) => {
        try {
            const result = await meetupApi.setGuestCountFor(api, meetup._id, hostClerkId, count);
            if (result.meetup) setMeetup(result.meetup);
            if (hostClerkId === currentUser.clerkId) setLocalGuestCount(count);
            queryClient.invalidateQueries({ queryKey: ['meetups'] });
            broadcastMeetupUpdate(getToken, meetupGroupId);
            haptic.success();
        } catch (e: any) {
            Alert.alert('Error', e?.response?.data?.message || 'Could not remove the guests. Please try again.');
        }
    };

    const confirmRemoveGuests = (host: User) => {
        const current = (meetup.guests || []).find(g => g.userId === host.clerkId)?.count ?? 0;
        if (!host.clerkId || current === 0) return;
        const name = getUserDisplayName(host);
        const buttons: { text: string; style?: 'cancel' | 'destructive'; onPress?: () => void }[] = [];
        if (current > 1) buttons.push({ text: 'Remove 1 guest', onPress: () => removeGuests(host.clerkId!, current - 1) });
        buttons.push({ text: current > 1 ? `Remove all ${current}` : 'Remove guest', style: 'destructive', onPress: () => removeGuests(host.clerkId!, 0) });
        buttons.push({ text: 'Cancel', style: 'cancel' });
        Alert.alert(
            host._id === currentUser._id ? 'Remove your guests?' : `Remove ${name}'s guests?`,
            host._id === currentUser._id ? undefined : `${name} will be notified. Freed spots go to the waitlist.`,
            buttons,
        );
    };

    const renderGuestTiles = (g: { userId: string; count: number }) => {
        const host = (meetup.members || []).find(m => (m as any).clerkId === g.userId);
        const hostName = host ? getUserDisplayName(host) : 'A member';
        const removable = canRemoveGuestsOf(host);
        return Array.from({ length: g.count }, (_, i) => {
            const tile = (
                <>
                    <View style={[styles.gridAvatar, styles.gridAvatarPlaceholder, styles.guestAvatarPlaceholder]}>
                        <Feather name="user" size={22} color="#FFFFFF" />
                    </View>
                    <Text style={[styles.gridName, { color: colors.textSecondary }]} numberOfLines={1}>{hostName}&apos;s Guest</Text>
                </>
            );
            return removable ? (
                <PressableOpacity
                    key={`guest-${g.userId}-${i}`}
                    style={styles.gridItem}
                    onPress={() => confirmRemoveGuests(host!)}
                    accessibilityLabel={`${hostName}'s guest. Tap to remove guests.`}
                >
                    {tile}
                </PressableOpacity>
            ) : (
                <View key={`guest-${g.userId}-${i}`} style={styles.gridItem}>{tile}</View>
            );
        });
    };

    const renderSectionHeader = (label: string, count: number, color: string, rightElement?: React.ReactNode) => (
        <View style={styles.sectionHeaderWrap}>
            <View style={styles.sectionHeaderRow}>
                <Text style={[styles.sectionHeaderText, { color, marginBottom: 0 }]}>{label} - {count}</Text>
                {rightElement}
            </View>
            <View style={[styles.sectionHeaderLine, { backgroundColor: color, opacity: isDark ? 0.7 : 0.85 }]} />
        </View>
    );

    const applyStatus = (newStatus: 'scheduled' | 'cancelled', cancelNote?: string | null) => {
        // Apply the new status immediately - invalidateQueries alone leaves the card/modal
        // showing the old status until the background refetch lands.
        setMeetup(prev => prev ? { ...prev, status: newStatus, cancelNote: newStatus === 'cancelled' ? (cancelNote ?? null) : null } : prev);
        queryClient.setQueryData<Meetup[]>(['meetups'], (old) =>
            old?.map(m => m._id === meetup._id ? { ...m, status: newStatus, cancelNote: newStatus === 'cancelled' ? (cancelNote ?? null) : null } : m)
        );
        queryClient.invalidateQueries({ queryKey: ['meetups'] });
        broadcastMeetupUpdate(getToken, meetupGroupId);
    };

    const restoreThisMeetup = async () => {
        try {
            await meetupApi.restoreMeetup(api, meetup._id);
            applyStatus('scheduled');
            haptic.success();
            return true;
        } catch (e: any) {
            Alert.alert("Error", getErrorMessage(e, "Couldn't bring the meetup back. Please try again."));
            return false;
        }
    };

    const confirmCancelWithReason = async (reason: string) => {
        setIsCancelling(true);
        try {
            await meetupApi.cancelMeetup(api, meetup._id, reason || undefined);
            applyStatus('cancelled', reason || null);
            setCancelSheetVisible(false);
            onClose();
            toast.show({
                message: 'Meetup cancelled',
                kind: 'success',
                actionLabel: 'Undo',
                onAction: () => {
                    // The server's restore also tells everyone it's back on.
                    meetupApi.restoreMeetup(api, meetup._id)
                        .then(() => {
                            queryClient.invalidateQueries({ queryKey: ['meetups'] });
                            broadcastMeetupUpdate(getToken, meetupGroupId);
                        })
                        .catch(() => {});
                },
            });
        } catch (e: any) {
            Alert.alert("Error", getErrorMessage(e, "Couldn't cancel the meetup. Please try again."));
        } finally {
            setIsCancelling(false);
        }
    };

    const handleCancelMeetup = () => {
        if (isExpired) return; // Can't cancel or restore an ended meetup
        if (!requireOnline(isCancelled ? 'bring this meetup back' : 'cancel this meetup')) return;
        if (isCancelled) {
            Alert.alert("Reactivate Meetup", "Bring this meetup back? Everyone will be notified.", [
                { text: "No", style: "cancel" },
                { text: "Yes", onPress: () => { restoreThisMeetup(); } },
            ]);
            return;
        }
        setCancelSheetVisible(true);
    };


    const resolvedLocation = meetup.location || (meetup.group as any)?.defaultLocation || '';
    const headerVideoService = detectVideoService(resolvedLocation);
    const frequencyDetail = buildFrequencyDetail(meetup);
    const frequencyLabel = meetup.frequency
        ? `${FREQUENCY_LABELS[meetup.frequency]}${frequencyDetail ? ` (${frequencyDetail})` : ''}`
        : null;

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: modalBackgroundColor }]} edges={['top', 'bottom']}>
            <View style={[styles.header, { borderBottomColor: colors.border }]}>
                <PressableOpacity onPress={onClose} style={styles.closeButton}>
                    <Feather name="x" size={28} color={colors.textFaint} />
                </PressableOpacity>
                <Animated.View layout={LinearTransition.duration(300).easing(Easing.out(Easing.cubic))} style={styles.headerTitleContainer}>
                    {/* Date, then time (a range when there is an end time), then the address below. */}
                    <Text style={[styles.headerTitle, { color: colors.textFaint }]}>
                        {formatMeetupDate(meetup, { weekday: 'short', month: 'short', day: 'numeric' })}
                    </Text>
                    <Text style={[styles.headerTitle, styles.headerTime, { color: colors.textFaint }]}>
                        {formatMeetupTimeRange(meetup)}
                    </Text>
                    {!!resolvedLocation && (
                        <View style={styles.headerLocationWrap}>
                            {/* Off-screen measuring clone — its full, unlimited-line layout tells us
                                whether the real (1-line) text below is actually being truncated. */}
                            <Text
                                style={[styles.headerLocation, styles.headerLocationMeasure]}
                                onTextLayout={(e) => setLocationTruncated(e.nativeEvent.lines.length > 1)}
                            >
                                {resolvedLocation}
                            </Text>
                            <Animated.View layout={LinearTransition.duration(300).easing(Easing.out(Easing.cubic))} style={styles.headerLocationRow}>
                                <Pressable
                                    onPress={() => handleOpenLocation(resolvedLocation)}
                                    style={styles.headerLocationTextWrap}
                                >
                                    <View style={styles.headerLocationInnerRow}>
                                        {!!headerVideoService && (
                                            <View style={styles.headerLocationIcon}>
                                                <VideoServiceIcon service={headerVideoService} size={14} />
                                            </View>
                                        )}
                                        <Animated.Text
                                            key={locationExpanded ? 'expanded' : 'collapsed'}
                                            entering={FadeIn.duration(200).delay(80)}
                                            exiting={FadeOut.duration(120)}
                                            style={[styles.headerLocation, { color: colors.textFaint }]}
                                            numberOfLines={locationExpanded ? undefined : 1}
                                        >
                                            {resolvedLocation}
                                        </Animated.Text>
                                    </View>
                                </Pressable>
                                {locationTruncated && (
                                    <Pressable
                                        onPress={() => {
                                            const next = !locationExpanded;
                                            setLocationExpanded(next);
                                            locationChevronRotation.value = withSpring(next ? 180 : 0, { damping: 12, stiffness: 160 });
                                            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                                        }}
                                        hitSlop={8}
                                    >
                                        <Animated.View style={[styles.headerLocationChevron, locationChevronStyle]}>
                                            <Feather name="chevron-down" size={14} color={colors.textFaint} />
                                        </Animated.View>
                                    </Pressable>
                                )}
                            </Animated.View>
                        </View>
                    )}
                </Animated.View>
                <View style={{ width: 44 }} />
            </View>

            <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
                <View style={{ marginBottom: showRsvpSelector ? 32 : 14 }}>
                    {isCancelled && (
                        <View style={[
                            styles.cancelBanner,
                            { justifyContent: 'space-between', backgroundColor: isDark ? '#3B1E1E' : '#FEF2F2', borderColor: isDark ? '#5C2E2E' : '#FEE2E2' },
                        ]}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
                                <Feather name="alert-triangle" size={18} color={colors.danger} />
                                <View style={{ flex: 1 }}>
                                    <Text style={[styles.cancelBannerText, { color: colors.danger }]}>
                                        {meetup.cancelReason === 'minimum-headcount' ? 'Cancelled: minimum not met' : 'Meetup Cancelled'}
                                    </Text>
                                    {!!meetup.cancelNote && meetup.cancelReason !== 'minimum-headcount' && (
                                        <Text style={[styles.cancelBannerSubtext, { color: colors.danger }]}>{meetup.cancelNote}</Text>
                                    )}
                                    {meetup.cancelReason === 'minimum-headcount' && (
                                        <Text style={[styles.cancelBannerSubtext, { color: colors.danger }]}>
                                            {meetup.minAttendees
                                                ? `The RSVP deadline has passed and fewer than ${meetup.minAttendees} people were in.`
                                                : 'The RSVP deadline has passed and the minimum headcount wasn\'t met.'}
                                        </Text>
                                    )}
                                </View>
                            </View>
                            {canCancelOrRestore && (
                                <PressableOpacity onPress={handleCancelMeetup} style={[styles.reactivateBannerBtn, { backgroundColor: colors.brand }]}>
                                    <Text style={styles.reactivateBannerBtnText}>Reactivate</Text>
                                </PressableOpacity>
                            )}
                        </View>
                    )}
                    {isExpired && !isCancelled && (
                        <View style={[styles.cancelBanner, { backgroundColor: colors.backgroundAlt, borderColor: colors.border }]}>
                            <Feather name="clock" size={18} color={colors.textMuted} />
                            <Text style={[styles.cancelBannerText, { color: colors.textMuted }]}>This Meetup Has Ended</Text>
                        </View>
                    )}
                    {isHappeningNow && (
                        <View style={[styles.cancelBanner, { backgroundColor: isDark ? '#123330' : '#F0FDFB', borderColor: isDark ? '#1F5B54' : '#99F6E4' }]}>
                            <Feather name="radio" size={18} color={isDark ? colors.accentTeal : '#0F766E'} />
                            <Text style={[styles.cancelBannerText, { color: isDark ? colors.accentTeal : '#0F766E' }]}>Meetup Happening Right Now</Text>
                        </View>
                    )}

                    <Animated.View layout={LinearTransition.duration(350).easing(Easing.out(Easing.cubic))} style={{ marginTop: 8, marginBottom: 18 }}>
                        {isIn && (
                            <PulsingWatermark label="IN" style={styles.inWatermark} baseOpacity={0.32} peakOpacity={0.55} />
                        )}
                        {isOut && (
                            <PulsingWatermark label="OUT" style={styles.outWatermark} baseOpacity={0.32} peakOpacity={0.42} />
                        )}
                        <Animated.View layout={LinearTransition.duration(350).easing(Easing.out(Easing.cubic))} style={styles.nameCard}>
                            {!!frequencyLabel && (
                                <Text style={[styles.meetupFrequencyLabel, { color: colors.textFaint }]}>{frequencyLabel}</Text>
                            )}
                            <Text style={[
                                styles.meetupTitle,
                                { color: colors.textPrimary },
                                isReadOnly && [styles.strikeThrough, { color: colors.borderStrong }],
                            ]}>
                                {meetup.name}
                            </Text>
                            {!!meetup.description?.trim() && (
                                <Pressable
                                    onPress={() => {
                                        const next = !descriptionExpanded;
                                        setDescriptionExpanded(next);
                                        descriptionChevronRotation.value = withSpring(next ? 180 : 0, { damping: 12, stiffness: 160 });
                                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                                    }}
                                    onPressIn={() => { descriptionPressScale.value = withTiming(0.96, { duration: 100 }); }}
                                    onPressOut={() => { descriptionPressScale.value = withTiming(1, { duration: 150 }); }}
                                >
                                    <Animated.View
                                        layout={LinearTransition.duration(350).easing(Easing.out(Easing.cubic))}
                                        style={[
                                            styles.meetupDescriptionChip,
                                            { backgroundColor: colors.surfaceAlt },
                                            descriptionExpanded && styles.meetupDescriptionChipExpanded,
                                            descriptionPressStyle,
                                        ]}
                                    >
                                        <View style={styles.meetupDescriptionRow}>
                                            <Feather name="align-left" size={12} color={colors.textFaint} style={styles.meetupDescriptionIcon} />
                                            <Animated.Text
                                                key={descriptionExpanded ? 'expanded' : 'collapsed'}
                                                entering={FadeIn.duration(200).delay(80)}
                                                exiting={FadeOut.duration(120)}
                                                style={[styles.meetupDescriptionText, { color: colors.textMuted }]}
                                                numberOfLines={descriptionExpanded ? undefined : 1}
                                            >
                                                {/* Links become tappable once the description is open; collapsed, a tap just expands it. */}
                                                {descriptionExpanded
                                                    ? <LinkifiedText text={meetup.description.trim()} linkColor={colors.brand} />
                                                    : meetup.description.trim()}
                                            </Animated.Text>
                                            <Animated.View style={[styles.meetupDescriptionChevron, descriptionChevronStyle]}>
                                                <Feather name="chevron-down" size={14} color={colors.textFaint} />
                                            </Animated.View>
                                        </View>
                                    </Animated.View>
                                </Pressable>
                            )}
                        </Animated.View>
                    </Animated.View>

                    <Animated.View layout={LinearTransition.duration(350).easing(Easing.out(Easing.cubic))} style={[styles.actionRow, { justifyContent: 'center' }]}>
                        <PressableOpacity
                            onPress={openActionsMenu}
                            style={[styles.actionBtn, styles.moreActionBtn, { backgroundColor: colors.brandSoft, borderColor: colors.brand }]}
                            activeOpacity={0.7}
                        >
                            <Ionicons name="ellipsis-horizontal-circle-outline" size={22} color={colors.brand} />
                        </PressableOpacity>
                        {!isReadOnly && !isRsvpLocked && !isRsvpDeadlinePassed && hasRsvpResponse && (
                            <PressableOpacity
                                onPress={() => {
                                    setManualRsvpEdit(v => !v);
                                    setSwapIconNonce(n => n + 1);
                                }}
                                style={[styles.actionBtn, styles.inOutActionBtn]}
                                activeOpacity={0.7}
                            >
                                <View style={[StyleSheet.absoluteFill, { top: 0, height: '50%', backgroundColor: isDark ? '#123330' : '#F0FDFB', borderTopLeftRadius: 9, borderTopRightRadius: 9 }]} />
                                <View style={[StyleSheet.absoluteFill, { top: '50%', height: '50%', backgroundColor: isDark ? '#3B1E1E' : '#FFE4E1', borderBottomLeftRadius: 9, borderBottomRightRadius: 9 }]} />
                                <InOutSwapIcon burstNonce={swapIconNonce} />
                            </PressableOpacity>
                        )}
                    </Animated.View>
                    {rsvpQueued && (
                        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 8 }}>
                            <Feather name="clock" size={12} color={colors.textMuted} />
                            <Text style={{ color: colors.textMuted, fontSize: 12, marginLeft: 4 }}>Your RSVP sends when you're back online</Text>
                        </View>
                    )}
                </View>

                {!isReadOnly && (
                    <Animated.View layout={LinearTransition.duration(300)} style={{ marginTop: showRsvpSelector ? 24 : 0, marginBottom: (isRsvpLocked || isRsvpDeadlinePassed || showRsvpSelector) ? 60 : 0 }}>
                        {isRsvpLocked ? (
                            <View style={[styles.rsvpLockedBanner, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}>
                                <Feather name="lock" size={22} color={colors.textMuted} />
                                <Text style={[styles.rsvpLockedTitle, { color: colors.textMuted }]}>RSVPs Not Open Yet</Text>
                                <Text style={[styles.rsvpLockedSubtitle, { color: colors.textFaint }]}>
                                    Opens {describeRsvpOpensFor(meetup, currentUser?._id)}
                                </Text>
                            </View>
                        ) : isRsvpDeadlinePassed ? (
                            <View style={[styles.rsvpLockedBanner, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}>
                                <Feather name="lock" size={22} color={colors.textMuted} />
                                <Text style={[styles.rsvpLockedTitle, { color: colors.textMuted }]}>RSVP Deadline Passed</Text>
                                <Text style={[styles.rsvpLockedSubtitle, { color: colors.textFaint }]}>
                                    Closed {new Date(meetup.rsvpCloseDate!).toLocaleDateString(undefined, {
                                        weekday: 'short', month: 'short', day: 'numeric', timeZone: viewerZone()
                                    })}
                                </Text>
                            </View>
                        ) : !showRsvpSelector ? null : (
                            <Animated.View
                                key="rsvp-buttons"
                                entering={FadeIn.duration(220)}
                                exiting={FadeOut.duration(160)}
                                layout={LinearTransition.duration(280)}
                            >
                                <RsvpBreather active={isUndecided}>
                                    {({ boxStyle, inTextStyle, outTextStyle }) => (
                                        <View style={{ flexDirection: 'row', gap: 12 }}>
                                            {/* Split I'm In button */}
                                            <View style={{
                                                flex: 1, borderRadius: 16, overflow: 'hidden', height: 72,
                                                backgroundColor: isWaitlisted ? '#2563EB' : waitlistLocked ? '#9CA3AF' : (isFull && !isIn) ? (canBump ? colors.accentTeal : '#F97316') : inFilled ? colors.accentTeal : colors.surface,
                                            }}>
                                                <Animated.View style={[{
                                                    flex: 1, flexDirection: 'row', borderRadius: 16,
                                                    borderWidth: inFilled ? 0 : 1.5,
                                                    borderColor: colors.accentTeal,
                                                }, boxStyle]}>
                                                    <PressableOpacity
                                                        onPress={() => { setGuestExpanded(false); handleRsvpAction('in'); }}
                                                        disabled={isRsvping || waitlistLocked}
                                                        style={{ flex: 7, alignItems: 'center', justifyContent: 'center' }}
                                                    >
                                                        <Animated.Text style={[{ color: inFilled ? 'white' : colors.accentTeal, fontWeight: 'bold', fontSize: 18 }, inTextStyle]}>
                                                            {isWaitlisted ? "Waitlisted" : waitlistLocked ? "Full" : (isFull && !isIn) ? (canBump ? "Priority In" : "Join Waitlist") : "I'm In"}
                                                        </Animated.Text>
                                                    </PressableOpacity>
                                                    <View style={{ width: 1, backgroundColor: inFilled ? 'rgba(255,255,255,0.35)' : colors.border }} />
                                                    <PressableOpacity
                                                        onPress={() => setGuestExpanded(v => !v)}
                                                        disabled={isRsvping || waitlistLocked}
                                                        style={{ flex: 3, alignItems: 'center', justifyContent: 'center' }}
                                                    >
                                                        {guestExpanded
                                                            ? <Feather name="x" size={20} color={inFilled ? 'white' : colors.accentTeal} />
                                                            : <MaterialIcons name="group-add" size={22} color={inFilled ? 'white' : colors.accentTeal} />
                                                        }
                                                    </PressableOpacity>
                                                </Animated.View>
                                            </View>

                                            {/* Split I'm Out button */}
                                            <View style={{
                                                flex: 1, borderRadius: 16, overflow: 'hidden', height: 72,
                                                backgroundColor: outFilled ? colors.accentCoral : colors.surface,
                                            }}>
                                                <Animated.View style={[{
                                                    flex: 1, flexDirection: 'row', borderRadius: 16,
                                                    borderWidth: outFilled ? 0 : 1.5,
                                                    borderColor: colors.accentCoral,
                                                }, boxStyle]}>
                                                    <PressableOpacity
                                                        onPress={() => { setGuestExpanded(false); handleRsvpAction('out'); }}
                                                        disabled={isRsvping}
                                                        style={{ flex: 7, alignItems: 'center', justifyContent: 'center' }}
                                                    >
                                                        <Animated.Text style={[{ color: outFilled ? 'white' : colors.accentCoral, fontWeight: 'bold', fontSize: 18 }, outTextStyle]}>I'm Out</Animated.Text>
                                                    </PressableOpacity>
                                                    <View style={{ width: 1, backgroundColor: outFilled ? 'rgba(255,255,255,0.35)' : colors.border }} />
                                                    <PressableOpacity
                                                        onPress={handleRsvpOutAndMute}
                                                        disabled={isRsvping}
                                                        style={{ flex: 3, alignItems: 'center', justifyContent: 'center' }}
                                                    >
                                                        <Feather name="bell-off" size={20} color={outFilled ? 'white' : colors.accentCoral} />
                                                    </PressableOpacity>
                                                </Animated.View>
                                            </View>
                                        </View>
                                    )}
                                </RsvpBreather>

                                {/* Inline guest counter */}
                                {guestExpanded && (
                                    <View style={{ alignItems: 'center', marginTop: 10 }}>
                                        <Text style={{ fontSize: 11, fontWeight: '700', color: colors.textMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Add Guests?</Text>
                                        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
                                            <PressableOpacity
                                                onPress={() => setLocalGuestCount(c => Math.max(0, c - 1))}
                                                disabled={localGuestCount === 0}
                                                style={{
                                                    width: 36, height: 36, borderRadius: 18,
                                                    backgroundColor: localGuestCount === 0 ? colors.surfaceAlt : colors.brandSoft,
                                                    borderWidth: 1.5,
                                                    borderColor: localGuestCount === 0 ? colors.border : colors.brand,
                                                    alignItems: 'center', justifyContent: 'center',
                                                }}
                                            >
                                                <Feather name="minus" size={16} color={localGuestCount === 0 ? colors.borderStrong : colors.brand} />
                                            </PressableOpacity>

                                            <Text style={{ fontSize: 24, fontWeight: '900', color: colors.textPrimary, minWidth: 28, textAlign: 'center' }}>
                                                {localGuestCount}
                                            </Text>

                                            <PressableOpacity
                                                onPress={() => setLocalGuestCount(c => c + 1)}
                                                style={{
                                                    width: 36, height: 36, borderRadius: 18,
                                                    backgroundColor: colors.brandSoft,
                                                    borderWidth: 1.5, borderColor: colors.brand,
                                                    alignItems: 'center', justifyContent: 'center',
                                                }}
                                            >
                                                <Feather name="plus" size={16} color={colors.brand} />
                                            </PressableOpacity>

                                            <PressableOpacity
                                                onPress={async () => {
                                                    setGuestExpanded(false);
                                                    await performSetGuests(localGuestCount);
                                                    if (!isIn) performRsvp('in');
                                                }}
                                                disabled={isRsvping || isSettingGuests}
                                                style={{
                                                    width: 36, height: 36, borderRadius: 18,
                                                    backgroundColor: colors.accentTeal,
                                                    borderWidth: 1.5, borderColor: '#3FABA1',
                                                    alignItems: 'center', justifyContent: 'center',
                                                    marginLeft: 6,
                                                }}
                                            >
                                                {(isRsvping || isSettingGuests)
                                                    ? <ActivityIndicator size="small" color="white" />
                                                    : <Feather name="check" size={18} color="white" />
                                                }
                                            </PressableOpacity>
                                        </View>
                                    </View>
                                )}
                            </Animated.View>
                        )}
                    </Animated.View>
                )}

                <MeetupTournamentCard
                    meetup={meetup}
                    currentUserId={currentUser._id}
                    canManage={canManage}
                    onOpen={leaveTo}
                />

                <Animated.View layout={LinearTransition.duration(300)} style={{ marginBottom: 40, marginTop: 8 }}>
                    {renderSectionHeader('In', goingUsers.length + totalGuestsForInTab, colors.accentTeal,
                        <Text style={[styles.sectionHeaderText, { color: colors.accentTeal, marginBottom: 0 }]}>
                            {meetup.capacity > 0 ? `Max: ${meetup.capacity}` : 'Unlimited'}
                        </Text>
                    )}
                    <View style={styles.grid}>
                        {goingUsers.length === 0 && totalGuestsForInTab === 0 && (
                            <Text style={[styles.emptyText, { color: colors.textFaint }]}>No one is in yet.</Text>
                        )}
                        {goingUsers.map(user => renderUserTile(user, user._id))}
                        {allGuestEntries.flatMap(renderGuestTiles)}
                    </View>

                    {renderSectionHeader('Out', outUsers.length, colors.accentCoral)}
                    <View style={styles.grid}>
                        {outUsers.length === 0 && <Text style={[styles.emptyText, { color: colors.textFaint }]}>No one is out.</Text>}
                        {outUsers.map(user => renderUserTile(user, user._id))}
                    </View>

                    {renderSectionHeader('Undecided', undecidedUsers.length, colors.textFaint,
                        canManage && undecidedUsers.length > 0 ? (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                {meetup.lastRemindedAt ? (
                                    <Text style={{ color: colors.textFaint, fontSize: 11, fontWeight: '600' }}>Reminded {formatAgo(meetup.lastRemindedAt)}</Text>
                                ) : null}
                                <PressableOpacity onPress={handleRemindAll} disabled={isSendingReminder} style={[styles.remindAllBtn, { backgroundColor: colors.brandSoft, borderColor: colors.brand }]} activeOpacity={0.7}>
                                    <Feather name="bell" size={12} color={colors.brand} />
                                    <Text style={[styles.remindAllText, { color: colors.brand }]}>Remind All</Text>
                                </PressableOpacity>
                            </View>
                        ) : undefined
                    )}
                    <View style={styles.grid}>
                        {undecidedUsers.length === 0 && <Text style={[styles.emptyText, { color: colors.textFaint }]}>Everyone has responded.</Text>}
                        {undecidedUsers.map(user => renderUserTile(user, user._id))}
                    </View>

                    {waitlistUsers.length > 0 && (
                        <>
                            {renderSectionHeader('Waitlist', waitlistUsers.length, isDark ? '#5B9EE8' : '#2563EB')}
                            <View style={styles.grid}>
                                {waitlistUsers.map((user, index) => renderUserTile(user, user._id, { waitlistPosition: index + 1 }))}
                            </View>
                        </>
                    )}
                </Animated.View>

                {canCancelOrRestore && !isCancelled && (
                    <View style={[styles.ownerSection, { borderTopColor: colors.border }]}>
                        <PressableOpacity onPress={handleCancelMeetup} style={[styles.cancelToggle, { borderColor: colors.danger, backgroundColor: isDark ? '#3B1E1E' : '#FEF2F2' }]}>
                            <Text style={[styles.cancelToggleText, { color: colors.danger }]}>Cancel This Meetup</Text>
                        </PressableOpacity>
                    </View>
                )}
            </ScrollView>

            {/* Actions Menu */}
            <ActionSheet
                visible={isActionsMenuVisible}
                onClose={() => setIsActionsMenuVisible(false)}
                items={[
                    ...(canEditOrCancel ? [{
                        key: 'edit',
                        label: 'Edit Meetup',
                        icon: <Feather name="edit-2" size={18} color="#F59E0B" />,
                        iconBg: isDark ? '#3A2E12' : '#FFFBEB',
                        onPress: openEditModal,
                    }] : []),
                    {
                        key: 'calendar',
                        label: 'Add to Calendar',
                        icon: <Feather name="calendar" size={18} color="#16A34A" />,
                        iconBg: isDark ? '#132A1E' : '#F0FDF4',
                        onPress: handleAddToCalendar,
                    },
                    {
                        key: 'chat',
                        label: 'Go to Chat',
                        icon: <Feather name="message-circle" size={18} color="#0EA5E9" />,
                        iconBg: isDark ? '#1A2A42' : '#F0F9FF',
                        onPress: handleGoToChat,
                    },
                    {
                        key: 'invite',
                        label: 'Invite to Meetup',
                        icon: <Feather name="user-plus" size={18} color="#0D9488" />,
                        iconBg: isDark ? '#123330' : '#ECFDF5',
                        onPress: handleInviteToMeetup,
                    },
                    ...(showTourneySetup({ canManage, meetup, tournament }) ? [{
                        key: 'tourney',
                        label: 'Set up Teams & Tourneys',
                        icon: <Feather name="users" size={18} color="#7C3AED" />,
                        iconBg: isDark ? '#2A1F45' : '#F5F3FF',
                        onPress: () => leaveTo({ pathname: '/tournament-setup/[meetupId]', params: { meetupId: meetup._id, groupId: meetup.group._id } }),
                    }] : []),
                ]}
            />

            {/* Who's riding with a driver (from a Driver pill) */}
            <ActionSheet
                visible={!!ridersDriverId}
                onClose={() => setRidersDriverId(null)}
                title={ridersDriverId === currentUser._id
                    ? 'Riding with you'
                    : `Riding with ${(meetup.members || []).find(m => m._id === ridersDriverId)?.firstName?.trim() || 'them'}`}
                items={(() => {
                    if (!ridersDriverId) return [];
                    const riders = ridersOf(meetup, ridersDriverId, currentUser._id);
                    if (riders.length === 0) {
                        return [{ key: 'none', label: 'No one riding yet', icon: <Feather name="users" size={18} color={colors.textMuted} />, iconBg: colors.surfaceAlt }];
                    }
                    return riders.map(r => ({
                        key: r.key,
                        label: r.label,
                        icon: <Feather name={r.isGuest ? 'user-plus' : 'user'} size={18} color={colors.textMuted} />,
                        iconBg: colors.surfaceAlt,
                    }));
                })()}
            />

            {/* Start DM Confirmation Sheet */}
            <Modal
                visible={!!dmTargetUser}
                transparent
                animationType="slide"
                onRequestClose={() => setDmTargetUser(null)}
            >
                <Pressable style={[dmStyles.backdrop, { backgroundColor: colors.overlay }]} onPress={() => setDmTargetUser(null)}>
                    <Pressable style={[dmStyles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(40, insets.bottom + 16) }]} onPress={() => {}}>
                        <View style={[dmStyles.dragHandle, { backgroundColor: colors.borderStrong }]} />
                        {dmTargetUser && (
                            <>
                                <Image
                                    source={{ uri: dmTargetUser.profilePicture || `https://placehold.co/100x100/EEE/31343C/png?text=${getUserInitial(dmTargetUser)}` }}
                                    style={[dmStyles.avatar, { backgroundColor: colors.backgroundAlt }]}
                                />
                                <Text style={[dmStyles.name, { color: colors.textPrimary }]}>
                                    {getUserDisplayName(dmTargetUser)}
                                </Text>
                                <PressableOpacity
                                    style={[dmStyles.dmBtn, { backgroundColor: colors.brand }]}
                                    onPress={handleSendDM}
                                    disabled={isCreatingDM}
                                    activeOpacity={0.8}
                                >
                                    {isCreatingDM
                                        ? <ActivityIndicator color="#fff" size="small" />
                                        : <Text style={dmStyles.dmBtnText}>Send DM</Text>
                                    }
                                </PressableOpacity>
                                {canManage && undecidedUsers.some(u => u._id === dmTargetUser._id) && (
                                    <PressableOpacity
                                        style={[dmStyles.remindBtn, { backgroundColor: colors.brandSoft, borderColor: colors.brand }]}
                                        onPress={() => handleSendReminder(dmTargetUser._id)}
                                        disabled={isSendingReminder}
                                        activeOpacity={0.8}
                                    >
                                        {isSendingReminder
                                            ? <ActivityIndicator color={colors.brand} size="small" />
                                            : <Text style={[dmStyles.remindBtnText, { color: colors.brand }]}>Send Reminder</Text>
                                        }
                                    </PressableOpacity>
                                )}
                                {canManageTarget(dmTargetUser) && (() => {
                                    const targetIsIn = meetup.in?.some(u => getUserId(u) === dmTargetUser._id) ?? false;
                                    const targetIsOut = meetup.out?.some(u => getUserId(u) === dmTargetUser._id) ?? false;
                                    return (
                                        <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
                                            <PressableOpacity
                                                style={[dmStyles.rsvpActionBtn, { backgroundColor: colors.accentTeal }, targetIsIn && dmStyles.rsvpActionBtnDisabled]}
                                                onPress={() => handleAdminRsvpChange(dmTargetUser._id, 'in')}
                                                disabled={isUpdatingTargetRsvp || targetIsIn}
                                                activeOpacity={0.8}
                                            >
                                                {isUpdatingTargetRsvp
                                                    ? <ActivityIndicator color="#fff" size="small" />
                                                    : <Text style={dmStyles.rsvpActionBtnText}>Mark as In</Text>
                                                }
                                            </PressableOpacity>
                                            <PressableOpacity
                                                style={[dmStyles.rsvpActionBtn, { backgroundColor: colors.accentCoral }, targetIsOut && dmStyles.rsvpActionBtnDisabled]}
                                                onPress={() => handleAdminRsvpChange(dmTargetUser._id, 'out')}
                                                disabled={isUpdatingTargetRsvp || targetIsOut}
                                                activeOpacity={0.8}
                                            >
                                                {isUpdatingTargetRsvp
                                                    ? <ActivityIndicator color="#fff" size="small" />
                                                    : <Text style={dmStyles.rsvpActionBtnText}>Mark as Out</Text>
                                                }
                                            </PressableOpacity>
                                        </View>
                                    );
                                })()}
                                {canManageTarget(dmTargetUser) && assignmentsActive(meetup)
                                    && (meetup.in?.some(u => getUserId(u) === dmTargetUser._id) ?? false) && (
                                    <PressableOpacity
                                        style={dmStyles.remindBtn}
                                        onPress={() => {
                                            const target = dmTargetUser;
                                            setDmTargetUser(null);
                                            // Let this sheet finish dismissing before presenting the next (iOS).
                                            setTimeout(() => setAssignTarget(target), 350);
                                        }}
                                        activeOpacity={0.8}
                                    >
                                        <Text style={dmStyles.remindBtnText}>Edit Assignments</Text>
                                    </PressableOpacity>
                                )}
                                {canManageTarget(dmTargetUser) && (() => {
                                    const n = (meetup.guests || []).find(g => g.userId === dmTargetUser.clerkId)?.count ?? 0;
                                    if (n === 0 || isReadOnly) return null;
                                    return (
                                        <PressableOpacity
                                            style={dmStyles.remindBtn}
                                            onPress={() => {
                                                const target = dmTargetUser;
                                                setDmTargetUser(null);
                                                setTimeout(() => confirmRemoveGuests(target), 350);
                                            }}
                                            activeOpacity={0.8}
                                        >
                                            <Text style={[dmStyles.remindBtnText, { color: colors.danger }]}>Remove Guests ({n})</Text>
                                        </PressableOpacity>
                                    );
                                })()}
                            </>
                        )}
                    </Pressable>
                </Pressable>
            </Modal>

            <MeetupConfirmSheet
                visible={selfConfirmOpen}
                meetup={meetup}
                currentUserId={currentUser._id}
                onClose={() => setSelfConfirmOpen(false)}
                onUpdated={(m) => {
                    setMeetup(m);
                    queryClient.invalidateQueries({ queryKey: ['meetups'] });
                    broadcastMeetupUpdate(getToken, meetupGroupId);
                }}
                onStale={() => queryClient.invalidateQueries({ queryKey: ['meetups'] })}
            />

            {reviewUser && (
                <MeetupConfirmSheet
                    visible
                    mode="review"
                    meetup={meetup}
                    currentUserId={currentUser._id}
                    subject={{ id: reviewUser._id, name: getUserDisplayName(reviewUser) }}
                    onClose={() => setReviewUser(null)}
                    // Message, Remind, Mark In/Out, Edit Assignments: the person sheet.
                    onMoreOptions={reviewUser._id === currentUser._id ? undefined : () => {
                        const target = reviewUser;
                        setReviewUser(null);
                        // Let this sheet finish dismissing before presenting the next (iOS).
                        setTimeout(() => setDmTargetUser(target), 350);
                    }}
                />
            )}

            {assignTarget && (
                <AssignmentsSheet
                    visible
                    meetup={meetup}
                    currentUserId={currentUser._id}
                    forUser={{ id: assignTarget._id, name: getUserDisplayName(assignTarget) }}
                    onClose={() => setAssignTarget(null)}
                    onUpdated={(m) => {
                        setMeetup(m);
                        queryClient.invalidateQueries({ queryKey: ['meetups'] });
                        broadcastMeetupUpdate(getToken, meetupGroupId);
                    }}
                    onStale={() => queryClient.invalidateQueries({ queryKey: ['meetups'] })}
                />
            )}

            {/* Edit Meetup: the same form as Add Meetup, for this meetup only */}
            {editDraft && (
                <MeetupForm
                    visible
                    mode="edit"
                    draft={editDraft}
                    onChange={patch => setEditDraft(d => (d ? { ...d, ...patch } : d))}
                    isPremium={(meetup.group as any)?.isPremium !== false}
                    owner={(meetup.group as any)?.owner}
                    lockedNote="The group's owner needs Premium to turn these on."
                    questionsLink={openMeetupQuestions}
                    timezoneEditable={false}
                    saving={isUpdating}
                    onSubmit={handleUpdateMeetupDetails}
                    onClose={() => setEditDraft(null)}
                />
            )}

            <CancelReasonSheet
                visible={cancelSheetVisible}
                meetupName={meetup.name}
                busy={isCancelling}
                onClose={() => setCancelSheetVisible(false)}
                onConfirm={confirmCancelWithReason}
            />
            <RsvpResponseOverlay />
            {/* This sheet is a Modal, which covers the app-level toast ("You're offline..."). */}
            <ToastPortal />
        </SafeAreaView>
    );
};

export default MeetupDetailModal;