// Android-only tab bar. The native Material 3 NavigationBar draws a solid pill
// behind the selected icon with no per-icon animation hook; iOS keeps the native tab bar.
import React, { useEffect } from 'react';
import { Pressable, View, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import type { BottomTabBarProps } from 'expo-router/tabs';
import Svg, { Defs, Ellipse, RadialGradient, Stop } from 'react-native-svg';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { useThemeColors } from '@/contexts/AppearanceContext';

// Must match TAB_BAR_HEIGHT in utils/layout.ts (android: 80) or content shifts under the bar.
const BAR_HEIGHT = 80;

const SHADOW_WIDTH = 30;
const SHADOW_HEIGHT = 9;

const TAB_ICONS: Record<string, React.ComponentProps<typeof Feather>['name']> = {
  index: 'home',
  groups: 'users',
  profile: 'user',
};

const AnimatedTabIcon = ({ name, focused }: { name: React.ComponentProps<typeof Feather>['name']; focused: boolean }) => {
  const colors = useThemeColors();
  const activeColor = colors.brand;
  const inactiveColor = colors.textFaint;
  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);
  const shadowOpacity = useSharedValue(0);

  useEffect(() => {
    if (focused) {
      scale.value = withTiming(1.3, { duration: 200 });
      shadowOpacity.value = withTiming(1, { duration: 200 });
      opacity.value = withRepeat(
        withSequence(
          withTiming(0.55, { duration: 900, easing: Easing.inOut(Easing.sin) }),
          withTiming(1, { duration: 900, easing: Easing.inOut(Easing.sin) }),
        ),
        -1,
        false,
      );
    } else {
      scale.value = withTiming(1, { duration: 200 });
      shadowOpacity.value = withTiming(0, { duration: 200 });
      opacity.value = withTiming(1, { duration: 200 });
    }
  }, [focused]);

  const iconStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ scale: scale.value }],
  }));

  const shadowStyle = useAnimatedStyle(() => ({
    opacity: shadowOpacity.value * 0.35,
  }));

  return (
    <View style={styles.iconWrap}>
      <Animated.View style={[styles.shadow, shadowStyle]}>
        <Svg width={SHADOW_WIDTH} height={SHADOW_HEIGHT}>
          <Defs>
            {/* Darkest at the center, fading out toward the tapered tips. */}
            <RadialGradient id="tabShadowGradient" cx="50%" cy="50%" r="50%">
              <Stop offset="0%" stopColor={activeColor} stopOpacity={0.6} />
              <Stop offset="100%" stopColor={activeColor} stopOpacity={0.22} />
            </RadialGradient>
          </Defs>
          <Ellipse
            cx={SHADOW_WIDTH / 2}
            cy={SHADOW_HEIGHT / 2}
            rx={SHADOW_WIDTH / 2}
            ry={SHADOW_HEIGHT / 2}
            fill="url(#tabShadowGradient)"
          />
        </Svg>
      </Animated.View>
      <Animated.View style={iconStyle}>
        <Feather name={name} size={24} color={focused ? activeColor : inactiveColor} />
      </Animated.View>
    </View>
  );
};

export const AndroidTabBar = ({ state, descriptors, emitter, navigateToTab }: BottomTabBarProps) => {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const colors = useThemeColors();

  return (
    <View style={[
      styles.container,
      { height: BAR_HEIGHT + insets.bottom, paddingBottom: insets.bottom, backgroundColor: colors.surface, borderTopColor: colors.border },
    ]}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const isFocused = state.index === index;

        const onPress = () => {
          const event = emitter.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (event.defaultPrevented) return;

          if (!isFocused) {
            navigateToTab(route.key);
            return;
          }

          // Already focused. React Navigation's default pop-to-root only works if the
          // list screen sits under the current one — but Group Details can be reached
          // directly from chat, leaving it as the stack's only entry. Navigate to the
          // list explicitly so the tap always works.
          if (route.name === 'groups') {
            router.navigate('/groups');
          }
        };

        const onLongPress = () => {
          emitter.emit({ type: 'tabLongPress', target: route.key });
        };

        return (
          <Pressable
            key={route.key}
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            onPress={onPress}
            onLongPress={onLongPress}
            style={styles.tab}
          >
            <AnimatedTabIcon name={TAB_ICONS[route.name] ?? 'circle'} focused={isFocused} />
          </Pressable>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: '#E5E5EA',
  },
  tab: {
    flex: 1,
    height: BAR_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  shadow: {
    position: 'absolute',
    bottom: -17,
    width: SHADOW_WIDTH,
    height: SHADOW_HEIGHT,
  },
});
