import { Platform } from 'react-native';
import Purchases, { type PurchasesPackage } from 'react-native-purchases';

// Public SDK keys (RevenueCat -> Project settings -> API keys -> the app's public key).
// These are safe to ship in the app; the SECRET key lives only on the backend.
const IOS_KEY = process.env.EXPO_PUBLIC_REVENUECAT_IOS_KEY ?? '';
const ANDROID_KEY = process.env.EXPO_PUBLIC_REVENUECAT_ANDROID_KEY ?? '';

const apiKey = () => (Platform.OS === 'ios' ? IOS_KEY : Platform.OS === 'android' ? ANDROID_KEY : '');

let configured = false;
let configuredFor: string | null = null;

/** False on web, or when this build has no RevenueCat key (e.g. a local build without env vars). */
export const purchasesAvailable = () => !!apiKey();

/**
 * Starts RevenueCat for the signed-in user. The app user id is the Clerk id, which is exactly
 * what the backend looks up when RevenueCat's webhook fires. Safe to call repeatedly.
 */
export async function initPurchases(clerkId: string): Promise<boolean> {
  if (!purchasesAvailable()) return false;
  try {
    if (!configured) {
      Purchases.configure({ apiKey: apiKey(), appUserID: clerkId });
      configured = true;
      configuredFor = clerkId;
      if (__DEV__) void logIntroDiagnostics(); // TEMP-DIAG
    } else if (configuredFor !== clerkId) {
      await Purchases.logIn(clerkId);
      configuredFor = clerkId;
    }
    return true;
  } catch (err) {
    console.warn('[purchases] init failed', err);
    return false;
  }
}

// >>> TEMP-DIAG (intro offer debugging, 2026-11-27) — remove before commit
async function logIntroDiagnostics(): Promise<void> {
  try {
    Purchases.setLogLevel(Purchases.LOG_LEVEL.DEBUG);
    const offerings = await Purchases.getOfferings();
    const pkgs = offerings.current?.availablePackages ?? [];
    console.log(`[TEMP-DIAG] offering=${offerings.current?.identifier ?? 'none'} packages=${pkgs.length}`);
    for (const p of pkgs) {
      const pr: any = p.product;
      console.log(`[TEMP-DIAG] ${p.identifier} product=${pr.identifier} price=${pr.priceString} introPrice=${JSON.stringify(pr.introPrice ?? null)}`);
      if (Platform.OS === 'android') {
        const opts = (pr.subscriptionOptions ?? []).map((o: any) => ({ id: o.id, base: o.isBasePlan, free: !!o.freePhase, tags: o.tags }));
        console.log(`[TEMP-DIAG] ${p.identifier} defaultOption=${pr.defaultOption?.id ?? 'none'} options=${JSON.stringify(opts)}`);
      }
    }
    if (Platform.OS === 'ios' && pkgs.length) {
      const elig = await Purchases.checkTrialOrIntroductoryPriceEligibility(pkgs.map((p) => p.product.identifier));
      // status: 0 UNKNOWN, 1 INELIGIBLE, 2 ELIGIBLE, 3 NO_INTRO_OFFER_EXISTS
      console.log(`[TEMP-DIAG] eligibility=${JSON.stringify(elig)}`);
    }
  } catch (e: any) {
    console.log(`[TEMP-DIAG] failed: ${e?.message ?? e}`);
  }
}
// <<< TEMP-DIAG

/** Detaches the device from the current user on sign-out so the next user doesn't inherit purchases. */
export async function resetPurchases(): Promise<void> {
  if (!configured || !configuredFor) return;
  // Clear first so a second sign-out pass that lands while this one is awaiting doesn't log out twice.
  configuredFor = null;
  try {
    // logOut on an anonymous user makes the native SDK log a red ERROR even though we catch it.
    if (await Purchases.isAnonymous()) return;
    await Purchases.logOut();
  } catch {
    // Nothing to undo.
  }
}

/** Packages in the offering marked "current" in the RevenueCat dashboard. */
export async function getPackages(): Promise<PurchasesPackage[]> {
  const offerings = await Purchases.getOfferings();
  return offerings.current?.availablePackages ?? [];
}

export type PurchaseResult = 'purchased' | 'cancelled';

export async function purchase(pkg: PurchasesPackage): Promise<PurchaseResult> {
  try {
    await Purchases.purchasePackage(pkg);
    return 'purchased';
  } catch (err: any) {
    if (err?.userCancelled) return 'cancelled';
    throw err;
  }
}

export async function restore(): Promise<void> {
  await Purchases.restorePurchases();
}
