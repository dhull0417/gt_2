import { isGifUrl, isGifAsset, mediaLabel, MAX_GIF_BYTES } from '../chatGif';

describe('isGifUrl', () => {
  it('ignores the query string', () => {
    expect(isGifUrl('https://x/chat/g/c.gif?t=123')).toBe(true);
  });
  it('is case-insensitive', () => {
    expect(isGifUrl('https://x/chat/g/c.GIF')).toBe(true);
  });
  it('is false for photos and missing urls', () => {
    expect(isGifUrl('https://x/chat/g/c.jpg?t=1')).toBe(false);
    expect(isGifUrl('https://x/chat/g/gif.jpg')).toBe(false);
    expect(isGifUrl(null)).toBe(false);
    expect(isGifUrl(undefined)).toBe(false);
  });
});

describe('isGifAsset', () => {
  it('trusts the mime type', () => {
    expect(isGifAsset({ mimeType: 'image/gif', uri: 'file:///a' })).toBe(true);
  });
  it('recognises a .gif file name with no mime type', () => {
    expect(isGifAsset({ fileName: 'Funny.GIF', uri: 'content://x' })).toBe(true);
    expect(isGifAsset({ uri: 'file:///cache/a.gif' })).toBe(true);
  });
  it('is false for photos', () => {
    expect(isGifAsset({ mimeType: 'image/jpeg', fileName: 'a.jpg', uri: 'file:///a.jpg' })).toBe(false);
  });
});

describe('mediaLabel', () => {
  it('says GIF for a GIF and Photo otherwise', () => {
    expect(mediaLabel('https://x/c.gif?t=1')).toBe('GIF');
    expect(mediaLabel('https://x/c.jpg')).toBe('📷 Photo');
  });
});

it('caps GIFs at 8 MB', () => {
  expect(MAX_GIF_BYTES).toBe(8 * 1024 * 1024);
});
