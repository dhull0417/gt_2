import { archiveMeetups, ARCHIVE_FIELDS } from "../utils/groupStats.js";
import asyncHandler from "express-async-handler";
import Meetup from "../models/meetup.model.js";
import Group from "../models/group.model.js";
import User from "../models/user.model.js";
import Poll from "../models/poll.model.js";
import { RSVP_REMINDER_STAGES } from "../utils/date.utils.js";
import { generateMeetupsForGroup } from "../utils/meetupGeneration.js";
import { notifyAndPersist } from "../utils/push.notifications.js";
import { groupHasPremium } from "../utils/premium.js";
import { evaluateDueMeetups } from "../utils/minimumHeadcount.js";
import { notifyOpenTiers } from "../utils/priorityRsvp.js";
import Notification from "../models/notification.model.js";
import { postSystemMessage } from "../utils/systemMessage.js";
import { clearNextMeetupMutesUpdate } from "../utils/groupMute.js";
import { expiryFilter } from "../utils/meetupEndTime.js";

/**
 * @desc    Generate meetups for groups whose nextGenerationAt is now due.
 *          Only groups with work to do are loaded — idle runs cost near-zero CPU.
 * @route   POST /api/jobs/regenerate-meetups
 */
export const regenerateMeetups = asyncHandler(async (req, res) => {
  const now = new Date();

  const groups = await Group.find({
    'schedules.nextGenerationAt': { $lte: now }
  });

  if (groups.length === 0) {
    return res.status(200).json({ generated: 0, message: "No groups due for generation." });
  }

  let generatedCount = 0;
  let failedCount = 0;

  // Per-group try/catch: one group throwing (e.g. a duplicate-key race
  // against a concurrent manual edit) shouldn't skip generation for every
  // other group due for this same run.
  for (const group of groups) {
    try {
      const { generatedCount: count } = await generateMeetupsForGroup(group);
      generatedCount += count;
    } catch (err) {
      failedCount++;
      console.error(`[Regenerate] Error for group ${group._id}:`, err);
    }
  }

  res.status(200).json({ generated: generatedCount, failed: failedCount, message: "Regeneration complete." });
});

/**
 * @desc    Expire meetups that are over: past their end time (endsAt), or 1 hour after
 *          start when they have none (mirrors meetupEndInstant in mobile/utils/meetupTime.ts).
 *          A single atomic DB operation — no JS loop.
 * @route   POST /api/jobs/expire-meetups
 */
export const expirePastMeetups = asyncHandler(async (req, res) => {
  const now = new Date();
  const filter = expiryFilter(now);

  const toExpire = await Meetup.find(
    filter,
    'group'
  );

  if (toExpire.length === 0) {
    return res.status(200).json({ message: "Job complete. Expired 0 meetups." });
  }

  const groupIds = [...new Set(toExpire.map(m => m.group.toString()))];

  const result = await Meetup.updateMany(
    filter,
    { $set: { status: 'expired' } }
  );

  if (groupIds.length > 0) {
    const { filter, update } = clearNextMeetupMutesUpdate(groupIds);
    await User.updateMany(filter, update);
    console.log(`[Expire] Unmuted users for ${groupIds.length} group(s).`);
  }

  console.log(`[Expire] Expired ${result.modifiedCount} meetup(s).`);
  res.status(200).json({ message: `Job complete. Expired ${result.modifiedCount} meetups.` });
});

/**
 * @desc    Delete expired and cancelled meetups that started more than 10 days ago.
 *          Only expired ones are archived for group stats; cancelled meetups
 *          don't count toward attendance or member titles.
 * @route   POST /api/jobs/cleanup-meetups
 */
export const cleanupExpiredMeetups = asyncHandler(async (req, res) => {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 10);

  // Keep each meetup's RSVPs for group stats before it's deleted. If archiving
  // fails, skip the delete so nothing is lost; the next run tries again.
  const old = await Meetup.find({ status: 'expired', startsAt: { $lte: cutoff } })
    .select(ARCHIVE_FIELDS)
    .lean();
  try {
    await archiveMeetups(old);
  } catch (err) {
    console.error('[Cleanup] Archive failed, skipping delete:', err);
    return res.status(500).json({ message: 'Archive failed; nothing deleted.' });
  }

  const result = await Meetup.deleteMany({
    status: { $in: ['expired', 'cancelled'] },
    startsAt: { $lte: cutoff }
  });

  console.log(`[Cleanup] Deleted ${result.deletedCount} old meetup(s).`);

  // Notifications older than 90 days are of no use any more.
  const notifCutoff = new Date();
  notifCutoff.setDate(notifCutoff.getDate() - 90);
  const oldNotifs = await Notification.deleteMany({ createdAt: { $lt: notifCutoff }, status: { $ne: 'pending' } });
  console.log(`[Cleanup] Deleted ${oldNotifs.deletedCount} old notification(s).`);

  res.status(200).json({ message: `Cleanup complete. Deleted ${result.deletedCount} old meetups and ${oldNotifs.deletedCount} old notifications.` });
});

/**
 * @desc    Send RSVP-open push notifications for meetups whose rsvpOpenDate just passed.
 *          Runs every minute independently of generation — cheap filtered query only.
 * @route   POST /api/jobs/notify-rsvp-open
 */
export const notifyRsvpOpen = asyncHandler(async (req, res) => {
  const now = new Date();

  // Priority groups: each group is told the moment its window opens, ahead of the
  // general open time. (Groups that open early because the ones before them answered
  // are announced from the RSVP itself.)
  const priorityMeetups = await Meetup.find({
    status: 'scheduled',
    startsAt: { $gte: now },
    rsvpNotified: false,
    rsvpOpenDate: { $gt: now },
    'priorityTiers.0': { $exists: true },
  }).select('_id group').lean();
  let tiersAnnounced = 0;
  for (const m of priorityMeetups) {
    try {
      const group = await Group.findById(m.group).select('owner').lean();
      if (!(await groupHasPremium(group))) continue;
      tiersAnnounced += await notifyOpenTiers(m._id);
    } catch (err) {
      console.error("notifyRsvpOpen priority failed for meetup", m._id.toString(), err);
    }
  }

  const toNotify = await Meetup.find({
    status: 'scheduled',
    startsAt: { $gte: now },
    rsvpOpenDate: { $lte: now },
    rsvpNotified: false,
  });

  for (const meetup of toNotify) {
    await Meetup.updateOne({ _id: meetup._id }, { $set: { rsvpNotified: true } });
    const dateStr = new Date(meetup.date).toLocaleDateString('en-US', {
      weekday: 'short', month: 'short', day: 'numeric', timeZone: meetup.timezone,
    });
    // Members of a priority group were already told when their window opened.
    const alreadyTold = new Set(
      (meetup.priorityTiers || [])
        .filter((_, i) => (meetup.priorityOpened || []).includes(i))
        .flatMap((t) => t.members.map((id) => id.toString()))
    );
    const members = (await User.find({ _id: { $in: meetup.members } }))
      .filter((u) => !alreadyTold.has(u._id.toString()));
    if (members.length > 0) {
      await notifyAndPersist(members, {
        title: "RSVPs Are Open!",
        body: `You can now RSVP to "${meetup.name}" on ${dateStr}.`,
        data: { meetupId: meetup._id.toString(), type: 'rsvp_open', groupId: meetup.group.toString() },
        type: 'meetup-rsvp-open',
        meetup: meetup._id,
        group: meetup.group,
      });
    }
  }

  res.status(200).json({ message: `Notified for ${toNotify.length} meetup(s); announced ${tiersAnnounced} priority group(s).` });
});

/**
 * @desc    "Starting soon" push 30 min before startsAt. Compares reminderNotifiedFor
 *          to the live startsAt (not a boolean) so a reschedule auto re-arms it.
 * @route   POST /api/jobs/notify-meetup-reminder
 */
export const notifyMeetupReminder = asyncHandler(async (req, res) => {
  const now = new Date();
  const windowEnd = new Date(now.getTime() + 30 * 60 * 1000);

  const toNotify = await Meetup.find({
    status: 'scheduled',
    startsAt: { $gte: now, $lte: windowEnd },
    $expr: { $ne: [{ $ifNull: ['$reminderNotifiedFor', null] }, '$startsAt'] },
  });

  for (const meetup of toNotify) {
    await Meetup.updateOne({ _id: meetup._id }, { $set: { reminderNotifiedFor: meetup.startsAt } });

    // Remind everyone still planning to go or undecided — skip anyone who already said they're out.
    const recipientIds = [...new Set([...meetup.in, ...meetup.undecided].map(id => id.toString()))];
    if (recipientIds.length === 0) continue;

    const recipients = await User.find({
      _id: { $in: recipientIds },
      expoPushToken: { $exists: true, $ne: null },
      // Group mutes are applied per kind inside notifyAndPersist.
    });

    if (recipients.length > 0) {
      await notifyAndPersist(recipients, {
        title: "⏰ 30 Minutes!",
        body: `"${meetup.name}" kicks off at ${meetup.time} — start heading over!`,
        data: { meetupId: meetup._id.toString(), type: 'meetup_reminder', groupId: meetup.group.toString() },
        type: 'meetup-starting-soon',
        meetup: meetup._id,
        group: meetup.group,
      });
    }
  }

  res.status(200).json({ message: `Reminded for ${toNotify.length} meetup(s).` });
});

// Reminder copy per stage key, shared between frequencies that behave
// identically (biweekly mirrors weekly; ordinal mirrors monthly).
const DAILY_REMINDER_COPY = {
  '4d':  (name) => `Don't forget to RSVP for "${name}"!`,
  '24h': (name) => `Tomorrow's the day — RSVP for "${name}" when you get a sec.`,
  '6h':  (name) => `Starting in a few hours — grab your spot for "${name}"!`,
};
const WEEKLY_REMINDER_COPY = {
  '7d':  (name) => `"${name}" is coming up next week — RSVP whenever you're ready.`,
  '3d':  (name) => `3 days until "${name}" — let us know if you're in!`,
  '24h': (name) => `Tomorrow's the day — RSVP for "${name}".`,
  '6h':  (name) => `"${name}" starts in a few hours — RSVP if you can make it!`,
};
const MONTHLY_REMINDER_COPY = {
  '14d': (name) => `Mark your calendar — "${name}" is two weeks out. RSVP whenever works.`,
  '7d':  (name) => `One week until "${name}" — RSVP when you get a chance.`,
  '3d':  (name) => `3 days until "${name}" — let us know if you're in!`,
  '24h': (name) => `Tomorrow's the day — RSVP for "${name}".`,
  '6h':  (name) => `"${name}" starts in a few hours — RSVP if you can make it!`,
};
// Semiannual and yearly get one extra, earlier reminder a month out.
const LONG_INTERVAL_REMINDER_COPY = {
  '30d': (name) => `"${name}" is a month away — RSVP whenever you know.`,
  ...MONTHLY_REMINDER_COPY,
};
const RSVP_REMINDER_COPY = {
  daily: DAILY_REMINDER_COPY,
  weekly: WEEKLY_REMINDER_COPY,
  biweekly: WEEKLY_REMINDER_COPY,
  monthly: MONTHLY_REMINDER_COPY,
  ordinal: MONTHLY_REMINDER_COPY,
  quarterly: MONTHLY_REMINDER_COPY,
  semiannual: LONG_INTERVAL_REMINDER_COPY,
  yearly: LONG_INTERVAL_REMINDER_COPY,
};

/**
 * @desc    Staged "you haven't RSVP'd yet" reminders, scaled by frequency
 *          (RSVP_REMINDER_STAGES). Only undecided members, only once RSVP is
 *          open. If multiple stages are overdue (e.g. after downtime), only the
 *          most imminent fires — earlier stages are marked sent, not queued late.
 * @route   POST /api/jobs/notify-rsvp-reminder-stages
 */
// bound the query to the longest configured offset (nothing due can be further
// out), so the scan stays proportional to what's imminent.
const MAX_STAGE_OFFSET_HOURS = Math.max(
  ...Object.values(RSVP_REMINDER_STAGES).flat().map(s => s.offsetHours)
);

export const notifyRsvpReminderStages = asyncHandler(async (req, res) => {
  const now = new Date();
  const horizon = new Date(now.getTime() + MAX_STAGE_OFFSET_HOURS * 60 * 60 * 1000);

  const toCheck = await Meetup.find({
    status: 'scheduled',
    startsAt: { $gt: now, $lte: horizon },
    frequency: { $ne: null },
    'undecided.0': { $exists: true },
  });

  let notifiedCount = 0;

  for (const meetup of toCheck) {
    if (meetup.rsvpOpenDate && new Date(meetup.rsvpOpenDate) > now) continue;
    // RSVP is closed but the event hasn't happened yet — nothing left to remind about.
    if (meetup.rsvpCloseDate && new Date(meetup.rsvpCloseDate) <= now) continue;

    const stages = RSVP_REMINDER_STAGES[meetup.frequency];
    if (!stages) continue;

    const sentSet = new Set(meetup.rsvpReminderStagesSent);
    const hoursUntilStart = (new Date(meetup.startsAt) - now) / (1000 * 60 * 60);
    const sortedAsc = [...stages].sort((a, b) => a.offsetHours - b.offsetHours);

    const dueStage = sortedAsc.find(s => hoursUntilStart <= s.offsetHours && !sentSet.has(s.key));
    if (!dueStage) continue;

    const stagesToMark = sortedAsc
      .filter(s => s.offsetHours >= dueStage.offsetHours && !sentSet.has(s.key))
      .map(s => s.key);
    await Meetup.updateOne(
      { _id: meetup._id },
      { $addToSet: { rsvpReminderStagesSent: { $each: stagesToMark } } }
    );

    const recipients = await User.find({
      _id: { $in: meetup.undecided },
      expoPushToken: { $exists: true, $ne: null },
      // Group mutes are applied per kind inside notifyAndPersist.
    });

    if (recipients.length > 0) {
      const buildBody = RSVP_REMINDER_COPY[meetup.frequency]?.[dueStage.key];
      await notifyAndPersist(recipients, {
        title: "RSVP Reminder",
        body: buildBody ? buildBody(meetup.name) : `Don't forget to RSVP for "${meetup.name}"!`,
        data: { meetupId: meetup._id.toString(), type: 'meetup_rsvp_reminder', groupId: meetup.group.toString() },
        type: 'meetup-rsvp-reminder',
        meta: { stage: dueStage.key },
        meetup: meetup._id,
        group: meetup.group,
      });
      notifiedCount++;
    }
  }

  res.status(200).json({ message: `Sent stage reminders for ${notifiedCount} meetup(s).` });
});

/**
 * @desc    Expire polls whose expiresAt has passed and notify members of the winning option(s).
 *          Ties are announced/highlighted as co-winners.
 * @route   POST /api/jobs/expire-polls
 */
export const expirePolls = asyncHandler(async (req, res) => {
  const now = new Date();

  const toExpire = await Poll.find({
    status: 'active',
    expiresAt: { $lte: now },
  }).populate('group', 'members');

  let expiredCount = 0;

  for (const poll of toExpire) {
    poll.status = 'expired';
    await poll.save();
    expiredCount++;

    const maxVotes = Math.max(...poll.options.map(o => o.voters.length));
    const winners = maxVotes > 0 ? poll.options.filter(o => o.voters.length === maxVotes) : [];
    const winnerText = winners.length > 0
      ? winners.map(w => w.text).join(' & ')
      : null;

    const body = winnerText
      ? `"${poll.prompt}" has closed. Winner: ${winnerText}.`
      : `"${poll.prompt}" has closed with no votes.`;

    if (poll.group?._id) await postSystemMessage(poll.group._id, body);

    const members = await User.find({ _id: { $in: poll.group?.members || [] } });
    if (members.length > 0) {
      await notifyAndPersist(members, {
        title: "Poll Closed",
        body,
        data: { pollId: poll._id.toString(), groupId: poll.group._id.toString(), type: 'poll_expired' },
        type: 'poll-closed',
        poll: poll._id,
        group: poll.group._id,
      });
    }
  }

  res.status(200).json({ message: `Job complete. Expired ${expiredCount} poll(s).` });
});

/**
 * @desc    Premium "minimum headcount": once a meetup's RSVP deadline has passed,
 *          cancel it if fewer people are in than the series requires, and tell
 *          everyone. Each meetup is evaluated exactly once (minimumChecked), so a
 *          restored meetup isn't cancelled again. Headcount = people who are in
 *          plus the guests they're bringing; the waitlist doesn't count. If the
 *          owner's Premium has lapsed the meetup is marked checked but left alone.
 *          Runs every minute like the other jobs.
 * @route   POST /api/jobs/cancel-under-minimum
 */
export const cancelUnderMinimum = asyncHandler(async (req, res) => {
  const { checked, cancelled } = await evaluateDueMeetups();
  res.status(200).json({ message: `Checked ${checked} meetup(s); cancelled ${cancelled}.` });
});
